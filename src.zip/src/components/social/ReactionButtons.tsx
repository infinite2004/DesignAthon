import { useState } from 'react';
import { Flame, ThumbsDown } from 'lucide-react';
import { useAppStore } from '../../store/appStore';

interface ReactionButtonsProps {
  postId: string;
  reactions?: {
    youCooked: number;
    youreCooked: number;
  };
  userReaction?: 'youCooked' | 'youreCooked' | null;
}

export function ReactionButtons({ postId, reactions, userReaction }: ReactionButtonsProps) {
  const reactToPost = useAppStore((state) => state.reactToPost);
  const removeReaction = useAppStore((state) => state.removeReaction);
  const [showFeedback, setShowFeedback] = useState<'youCooked' | 'youreCooked' | null>(null);

  const youCookedCount = reactions?.youCooked || 0;
  const youreCookedCount = reactions?.youreCooked || 0;

  const handleReaction = (reaction: 'youCooked' | 'youreCooked') => {
    if (userReaction === reaction) {
      // Remove reaction if clicking the same one
      removeReaction(postId);
    } else {
      // Add or change reaction
      reactToPost(postId, reaction);
      
      // Show feedback text
      setShowFeedback(reaction);
      setTimeout(() => setShowFeedback(null), 1000);
    }
  };

  return (
    <div className="relative">
      <div className="flex items-center gap-3">
        {/* You Cooked! - Positive reaction */}
        <button
          onClick={() => handleReaction('youCooked')}
          className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all touch-target ${
            userReaction === 'youCooked'
              ? 'bg-brand-teal text-white shadow-md'
              : 'bg-slate-100 text-slate-700 hover:bg-brand-teal/10 hover:text-brand-teal'
          }`}
        >
          <Flame
            size={18}
            className={userReaction === 'youCooked' ? 'fill-white' : ''}
          />
          <span className="text-sm font-medium">
            {youCookedCount > 0 ? youCookedCount : ''}
          </span>
        </button>

        {/* You're Cooked! - Negative reaction */}
        <button
          onClick={() => handleReaction('youreCooked')}
          className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all touch-target ${
            userReaction === 'youreCooked'
              ? 'bg-slate-700 text-white shadow-md'
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          <ThumbsDown
            size={18}
            className={userReaction === 'youreCooked' ? 'fill-white' : ''}
          />
          <span className="text-sm font-medium">
            {youreCookedCount > 0 ? youreCookedCount : ''}
          </span>
        </button>
      </div>
      
      {/* Feedback Text */}
      {showFeedback && (
        <div className="absolute left-1/2 -translate-x-1/2 -top-8 animate-fade-up">
          <p className={`text-sm font-semibold whitespace-nowrap ${
            showFeedback === 'youCooked' ? 'text-brand-teal' : 'text-slate-700'
          }`}>
            {showFeedback === 'youCooked' ? 'You cooked!' : "You're cooked!"}
          </p>
        </div>
      )}
    </div>
  );
}
