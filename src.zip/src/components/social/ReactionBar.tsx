import { ChefHat, MessageCircle, Bookmark } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useReactions } from '../../hooks/useReactions';
import { useAuth } from '../../providers/AuthProvider';
import { useAppStore } from '../../store/appStore';
import { useToast } from '../ui/ToastContext';
import { cn } from '../../lib/utils';
import type { Post } from '../../types';

type ReactionBarProps = {
  post: Post;
  onCommentPress?: () => void;
  onSavePress?: () => void;
  onRequestRecipe?: () => void;
  onMessagePoster?: () => void;
};

export function ReactionBar({ post, onCommentPress, onSavePress, onRequestRecipe, onMessagePoster }: ReactionBarProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { showToast } = useToast();
  const { reactions } = useReactions(post.id);
  const reCookPost = useAppStore((state) => state.reCookPost);
  const currentReaction = user ? reactions.find(r => r.userId === user.id) : undefined;
  
  // Check if this is the user's own post - compare both ID and username for safety
  const isOwnPost = user && (user.id === post.userId || user.username === post.user.username);

  const handleCooked = () => {
    if (post.recipeId && post.recipe && user?.id) {
      // Has recipe - save it and navigate to recipe detail page
      reCookPost(post.id);
      
      // Save the recipe to user's saved recipes
      const savedRecipe = {
        ...post.recipe,
        id: `saved-${post.recipeId}-${Date.now()}`,
        userId: user.id,
        sourceRecipeId: post.recipeId,
        createdAt: new Date(),
        tags: [...(post.recipe.tags || []), `from-@${post.user.username}`],
      };
      
      useAppStore.getState().addRecipe(savedRecipe);
      useAppStore.getState().saveRecipe(savedRecipe.id);
      
      // Navigate to the saved recipe detail page
      navigate(`/recipe/${savedRecipe.id}`);
      showToast('Recipe saved! Ready to re-cook 🍳', 'success');
    } else if (!isOwnPost) {
      // No recipe and not own post - request recipe
      if (onRequestRecipe) {
        onRequestRecipe();
      } else {
        // Fallback: navigate to post detail where request button is
        navigate(`/post/${post.id}`);
      }
    }
  };

  const cookedCount = reactions.filter(r => r.type === 'cooked').length;

  return (
    <div className="flex items-center gap-2 px-4 py-3 overflow-x-auto no-scrollbar">
      {/* Request Recipe button - for posts WITHOUT recipes */}
      {!isOwnPost && !post.recipeId && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleCooked();
          }}
          className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-brand-teal/10 text-brand-teal hover:bg-brand-teal/20 transition-all text-xs font-semibold touch-target whitespace-nowrap flex-shrink-0"
          aria-label="Request recipe"
        >
          <ChefHat size={14} />
          Request Recipe
        </button>
      )}
      
      {/* Re-cook button - for posts WITH recipes */}
      {post.recipeId && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleCooked();
          }}
          className={cn(
            "flex items-center gap-1.5 px-3 py-2 rounded-full transition-all text-xs font-semibold touch-target whitespace-nowrap flex-shrink-0",
            currentReaction?.type === 'cooked' 
              ? "bg-brand-teal text-white" 
              : "bg-brand-teal/10 text-brand-teal hover:bg-brand-teal/20"
          )}
          aria-label="Re-cook recipe"
        >
          <ChefHat size={14} />
          Re-cook {cookedCount > 0 && `(${cookedCount})`}
        </button>
      )}
      
      {/* Save Recipe button - for posts with recipes from others */}
      {!isOwnPost && post.recipeId && post.recipe && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            
            if (!post.recipe || !user?.id) return;
            
            // Create a new recipe object based on the post's recipe
            const savedRecipe = {
              ...post.recipe,
              id: `saved-${post.recipeId}-${Date.now()}`, // New unique ID
              userId: user.id, // Mark as saved by current user
              sourceRecipeId: post.recipeId, // Track original
              createdAt: new Date(),
              tags: [...(post.recipe.tags || []), `from-@${post.user.username}`],
            };
            
            // Add and save the recipe
            useAppStore.getState().addRecipe(savedRecipe);
            useAppStore.getState().saveRecipe(savedRecipe.id);
            showToast(`Recipe saved! From @${post.user.username}`, 'success');
          }}
          className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-slate-100 text-slate-700 hover:bg-slate-200 transition-all text-xs font-semibold touch-target whitespace-nowrap flex-shrink-0"
          aria-label="Save recipe"
        >
          <Bookmark size={14} />
          Save Recipe
        </button>
      )}
      
      {/* Message button - subtle text for posts with recipes */}
      {!isOwnPost && post.recipeId && onMessagePoster && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onMessagePoster();
          }}
          className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200 transition-all text-xs font-semibold touch-target whitespace-nowrap flex-shrink-0"
          aria-label="Message creator"
        >
          <MessageCircle size={14} />
          Message
        </button>
      )}

      <div className="flex-1 min-w-0" />

      <button
        onClick={(e) => {
          e.stopPropagation();
          if (onCommentPress) onCommentPress();
        }}
        className="flex items-center gap-1.5 text-gray-600 hover:text-brand-teal touch-target transition-all duration-200 active:scale-110 flex-shrink-0"
        aria-label="Comment"
      >
        <MessageCircle size={20} />
        <span className="text-sm font-medium">{post.comments || 0}</span>
      </button>

      <button
        onClick={(e) => {
          e.stopPropagation();
          if (onSavePress) onSavePress();
        }}
        className={cn(
          "touch-target transition-all duration-200 active:scale-110 flex-shrink-0",
          post.isSaved ? "text-brand-teal" : "text-gray-600 hover:text-brand-teal"
        )}
        aria-label={post.isSaved ? "Unsave post" : "Save post"}
      >
        <Bookmark size={20} className={post.isSaved ? "fill-current" : ""} />
      </button>
    </div>
  );
}

