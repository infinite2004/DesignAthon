import { useNavigate } from 'react-router-dom';
import { MessageCircle, Bookmark } from 'lucide-react';
import { useAppStore } from '../../store/appStore';
import { useToast } from '../../components/ui/ToastContext';
import type { Post } from '../../types';
import { Avatar } from '../media/Avatar';
import { cn } from '../../lib/utils';
import { useReactions } from '../../hooks/useReactions';
import { useAuth } from '../../providers/AuthProvider';

interface PostCardProps {
  post: Post;
  onPress?: () => void;
}

export function PostCardNew({ post, onPress }: PostCardProps) {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { user } = useAuth();
  const savedPosts = useAppStore((state) => state.savedPosts);
  const savePost = useAppStore((state) => state.savePost);
  const unsavePost = useAppStore((state) => state.unsavePost);
  const { reactions, react } = useReactions(post.id);
  
  const isSaved = savedPosts.includes(post.id);
  
  // Check if current user has reacted
  const userYouCooked = user ? reactions.some(r => r.type === 'cooked' && r.userId === user.id) : false;
  const userYoureCooked = user ? reactions.some(r => r.type === 'youre_cooked' && r.userId === user.id) : false;

  const handlePostClick = () => {
    if (onPress) {
      onPress();
    } else {
      navigate(`/post/${post.id}`);
    }
  };

  const handleComment = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/post/${post.id}`);
  };

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isSaved) {
      unsavePost(post.id);
      showToast('Post unsaved', 'success');
    } else {
      savePost(post.id);
      showToast('Post saved! 💾', 'success');
    }
  };

  const handleYouCooked = (e: React.MouseEvent) => {
    e.stopPropagation();
    react('cooked');
    showToast('You Cooked! 👨‍🍳', 'success');
  };

  const handleYoureCooked = (e: React.MouseEvent) => {
    e.stopPropagation();
    react('youre_cooked');
    showToast("You're Cooked! 🔥", 'success');
  };

  // Get dish name from recipe or caption
  const dishName = post.recipe?.title || post.caption.split('.')[0].substring(0, 50);

  return (
    <article className="mb-4">
      {/* User info above image - NO background */}
      <div className="flex items-center gap-2 px-4 pb-2">
        <Avatar
          src={post.user.avatar}
          initials={post.user.displayName ? post.user.displayName.split(' ').map(n => n[0]).join('').toUpperCase() : post.user.username?.charAt(0).toUpperCase() || 'U'}
          size={32}
        />
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-sm truncate">{post.user.displayName || post.user.username || 'User'}</h3>
        </div>
      </div>

      {/* Rounded square image with green outline - clickable */}
      <div className="px-4 pb-2">
        <div 
          onClick={handlePostClick}
          className="relative cursor-pointer group rounded-2xl overflow-hidden border-4 border-brand-teal"
        >
          {post.media.length > 0 && post.media[0] && !post.media[0].startsWith('blob:') ? (
            <div className="w-full aspect-square bg-gray-100 overflow-hidden relative">
              <img
                src={post.media[0]}
                alt={dishName}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  const parent = target.parentElement;
                  if (parent && !parent.querySelector('.image-fallback')) {
                    const fallback = document.createElement('div');
                    fallback.className = 'image-fallback absolute inset-0 flex items-center justify-center bg-gray-200';
                    fallback.innerHTML = '<span class="text-4xl">🍳</span>';
                    parent.appendChild(fallback);
                  }
                }}
              />
            </div>
          ) : (
            <div className="w-full aspect-square bg-gray-200 flex items-center justify-center">
              <span className="text-4xl">🍳</span>
            </div>
          )}
        </div>
      </div>

      {/* Dish name, description, and action icons below image - aligned with box */}
      <div className="px-4 pl-[24px]">
        {/* Dish name */}
        <h2 
          onClick={handlePostClick}
          className="font-bold text-base mb-1 line-clamp-1 cursor-pointer hover:text-brand-teal transition-colors"
        >
          {dishName}
        </h2>

        {/* One line description - clickable for read more */}
        <p 
          onClick={handlePostClick}
          className="text-sm text-gray-600 mb-3 line-clamp-1 cursor-pointer hover:text-gray-900 transition-colors"
        >
          {post.caption}
        </p>

        {/* All action buttons on one line */}
        <div className="flex items-center gap-2 pb-4 flex-wrap">
          <button
            onClick={handleYouCooked}
            className={cn(
              "flex items-center gap-1 px-3 py-1.5 rounded-full transition-all text-xs",
              userYouCooked 
                ? "bg-green-600 text-white font-extrabold shadow-md scale-105" 
                : "bg-green-50 text-green-700 font-medium hover:bg-green-100 border border-green-200"
            )}
            aria-label="You Cooked"
          >
            <span>❤️</span>
            <span>You Cooked!</span>
          </button>

          <button
            onClick={handleYoureCooked}
            className={cn(
              "flex items-center gap-1 px-3 py-1.5 rounded-full transition-all text-xs",
              userYoureCooked 
                ? "bg-orange-600 text-white font-extrabold shadow-md scale-105" 
                : "bg-orange-100 text-orange-600 font-medium hover:bg-orange-200"
            )}
            aria-label="You're Cooked"
          >
            <span>💀</span>
            <span>You're Cooked</span>
          </button>

          {/* Comment and Save buttons grouped together */}
          <div className="flex items-center gap-1">
            <button
              onClick={handleComment}
              className="flex items-center gap-1 px-2 py-1.5 text-gray-700 hover:text-brand-teal touch-target transition-all duration-200 active:scale-110"
              aria-label="Comment"
            >
              <MessageCircle size={20} className="transition-transform duration-200" />
              <span className="text-sm font-medium">{post.comments}</span>
            </button>

            <button
              onClick={handleSave}
              className={cn(
                "flex items-center gap-1.5 px-2 py-1.5 touch-target transition-all duration-200 active:scale-110",
                isSaved ? 'text-brand-teal' : 'text-gray-700 hover:text-brand-teal'
              )}
              aria-label={isSaved ? 'Unsave' : 'Save'}
            >
              <Bookmark size={20} className={cn(isSaved ? 'fill-current' : '', 'transition-transform duration-200')} />
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}

