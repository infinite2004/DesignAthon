export interface UserPreferences {
  goals: string[];
  budget: {
    period: 'week' | 'month';
    amount: number;
  };
  cookingFrequency: {
    daysPerWeek: number;
    proteinGoals: string[];
  };
  friends: string[];
  savedPosts: string[];
  savedRecipes: string[];
  cuisinePreferences: string[];
  weeklyGoals: {
    daysToCook: number;
    mealsPerDay: number;
    people: number;
    mealPrepGoals: string[];
  };
  dietaryRestrictions: {
    diets: string[]; // 'vegan', 'vegetarian', 'keto', 'paleo', etc.
    allergies: string[]; // 'nuts', 'dairy', 'gluten', 'shellfish', etc.
    restrictions: string[]; // 'no-alcohol', 'halal', 'kosher', etc.
    customKeywords: string[]; // User-defined keywords to avoid
  };
}

export interface SustainabilityTracking {
  daysCooked: number;
  daysGoal: number;
  moneySaved: number; // compared to eating out
  wasteSaved: number; // in grams
  newRecipesLearned: number;
  mealsShared: number;
}

