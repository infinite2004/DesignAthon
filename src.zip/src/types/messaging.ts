export interface DMMessage {
  id: string;
  conversationId: string;
  senderId: string;
  content: string;
  createdAt: Date;
  isRead: boolean;
}

export interface DMConversation {
  id: string;
  participants: string[]; // User IDs
  participantDetails: {
    id: string;
    username: string;
    displayName: string;
    avatar?: string;
  }[];
  lastMessage?: DMMessage;
  postId?: string; // If this conversation is about a specific post
  postPreview?: {
    caption: string;
    image: string;
  };
  createdAt: Date;
  updatedAt: Date;
}
