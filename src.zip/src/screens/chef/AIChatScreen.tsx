import { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Send, Sparkles, Image as ImageIcon, X } from 'lucide-react';
import { TextField } from '../../components/forms/TextField';
import { Chip } from '../../components/forms/Chip';
import { Avatar } from '../../components/media/Avatar';
import { formatTimeAgo } from '../../lib/utils';
import { useAuth } from '../../providers/AuthProvider';

type ChatMessage = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  image?: string;
  createdAt: Date;
};

const quickChips = [
  'Cheap meals',
  'Use only fridge',
  'Meal prep for 3 days',
  'Quick dinner ideas',
  'Vegetarian options',
];

export function AIChatScreen() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Hi! I\'m your AI cooking assistant. What would you like to cook today?',
      createdAt: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const hasProcessedInitialMessage = useRef(false);

  // Handle initial message from navigation state
  useEffect(() => {
    const initialMessage = (location.state as any)?.initialMessage;
    const shouldGenerateRecipes = (location.state as any)?.generateRecipes;
    
    console.log('AIChatScreen - Initial message:', initialMessage);
    console.log('AIChatScreen - Should generate recipes:', shouldGenerateRecipes);
    
    if (initialMessage && !hasProcessedInitialMessage.current) {
      hasProcessedInitialMessage.current = true;
      
      console.log('Processing initial message:', initialMessage);
      
      // Simulate sending the initial message
      const userMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'user',
        content: initialMessage,
        createdAt: new Date(),
      };
      
      setMessages(prev => [...prev, userMessage]);
      
      if (shouldGenerateRecipes) {
        // Show thinking state, then navigate to recipes
        setIsThinking(true);
        setTimeout(() => {
          const aiResponse: ChatMessage = {
            id: crypto.randomUUID(),
            role: 'assistant',
            content: `Perfect! Let me generate some recipes for you...`,
            createdAt: new Date(),
          };
          setMessages(prev => [...prev, aiResponse]);
          
          // Navigate to recipes after thinking
          setTimeout(() => {
            setIsThinking(false);
            navigate('/chef/ai-recipes', {
              state: {
                surpriseMe: true,
                surpriseKey: Date.now(),
              },
            });
          }, 2000);
        }, 1000);
      } else {
        // Regular chat response
        setTimeout(() => {
          const aiResponse: ChatMessage = {
            id: crypto.randomUUID(),
            role: 'assistant',
            content: `Great question! Based on "${initialMessage}", I can help you find the perfect recipes. What ingredients do you have available?`,
            createdAt: new Date(),
          };
          setMessages(prev => [...prev, aiResponse]);
        }, 1000);
      }
    }
  }, [location.state, navigate]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() && !selectedImage) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input || '(sent an image)',
      image: selectedImage || undefined,
      createdAt: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    
    // Auto-open the image in full screen when sent
    if (selectedImage) {
      setFullScreenImage(selectedImage);
    }
    
    setSelectedImage(null);
    setImagePreview(null);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: selectedImage 
          ? `I can see your image! Based on what you've shared, I can help you identify ingredients or suggest recipes. What would you like to know?`
          : `Based on your pantry, I recommend trying a simple pasta dish. Would you like me to generate a recipe?`,
        createdAt: new Date(),
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 1500);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setSelectedImage(result);
        setImagePreview(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setSelectedImage(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleQuickChip = (chip: string) => {
    setInput(chip);
  };

  return (
    <div className="flex flex-col h-screen bg-white pb-20">
      {/* Header - Fixed at top */}
      <header className="flex-shrink-0 bg-white border-b border-gray-200 safe-area-top z-40">
        <div className="flex items-center justify-between px-4 py-3">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 touch-target"
            aria-label="Back"
          >
            <ArrowLeft size={24} className="text-gray-600" />
          </button>
          <div className="flex items-center gap-2">
            <Sparkles size={20} className="text-teal" />
            <h1 className="text-sm font-semibold text-teal">AI Assistant</h1>
          </div>
          <div className="w-8" />
        </div>
      </header>

      {/* Messages - Scrollable area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => {
          const isUser = message.role === 'user';
          
          if (isUser) {
            console.log('Rendering user message:', message.content, 'Full message:', message);
          }
          
          return (
            <div
              key={message.id}
              className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              <div className="flex items-start gap-2 max-w-[80%]">
                {!isUser && (
                  <div className="w-8 h-8 rounded-full bg-teal/20 flex items-center justify-center flex-shrink-0">
                    <Sparkles size={16} className="text-teal" />
                  </div>
                )}
                <div
                  className={`rounded-2xl p-3 ${
                    isUser
                      ? 'bg-teal text-white'
                      : 'bg-gray-100 text-gray-900'
                  }`}
                  style={{ minWidth: '60px', overflow: 'visible' }}
                >
                  {message.image && (
                    <img
                      src={message.image}
                      alt="Sent image"
                      className="rounded-lg mb-2 max-w-full cursor-pointer hover:opacity-90 transition-opacity"
                      onClick={() => setFullScreenImage(message.image!)}
                    />
                  )}
                  <div className="text-sm break-words whitespace-normal w-full">
                    {message.content}
                  </div>
                  <p className={`text-xs mt-1 ${isUser ? 'text-white/70' : 'text-gray-500'}`}>
                    {formatTimeAgo(message.createdAt)}
                  </p>
                </div>
                {isUser && user && (
                  <Avatar
                    src={user.avatar}
                    initials={user.displayName[0]}
                    size={32}
                  />
                )}
              </div>
            </div>
          );
        })}
        
        {/* Thinking indicator */}
        {isThinking && (
          <div className="flex justify-start">
            <div className="flex items-start gap-2 max-w-[80%]">
              <div className="w-8 h-8 rounded-full bg-teal/20 flex items-center justify-center flex-shrink-0">
                <Sparkles size={16} className="text-teal animate-pulse" />
              </div>
              <div className="rounded-2xl p-3 bg-gray-100 text-gray-900">
                <div className="flex items-center gap-2">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                  </div>
                  <span className="text-xs text-gray-500">Thinking...</span>
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Chips - Above input */}
      {input === '' && (
        <div className="flex-shrink-0 px-4 py-2 border-t border-gray-200 bg-white">
          <div className="flex flex-wrap gap-2">
            {quickChips.map((chip) => (
              <Chip
                key={chip}
                label={chip}
                selected={false}
                onClick={() => handleQuickChip(chip)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Input - Fixed at bottom */}
      <div className="flex-shrink-0 px-4 py-3 bg-white border-t border-gray-200 safe-area-bottom">
        {/* Image Preview */}
        {imagePreview && (
          <div className="mb-3 relative inline-block">
            <img
              src={imagePreview}
              alt="Preview"
              className="rounded-lg max-h-32 object-cover"
            />
            <button
              onClick={handleRemoveImage}
              className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-lg"
              aria-label="Remove image"
            >
              <X size={16} />
            </button>
          </div>
        )}
        
        <div className="flex items-center gap-2">
          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageSelect}
            className="hidden"
          />
          
          {/* Image picker button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-xl touch-target transition-colors"
            aria-label="Attach image"
          >
            <ImageIcon size={20} />
          </button>
          
          <TextField
            value={input}
            onChange={setInput}
            placeholder="Ask me anything..."
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            className="flex-1"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() && !selectedImage}
            className="p-2 bg-teal text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed touch-target"
            aria-label="Send message"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
      
      {/* Full Screen Image Modal */}
      {fullScreenImage && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={() => setFullScreenImage(null)}
        >
          <button
            onClick={() => setFullScreenImage(null)}
            className="absolute top-4 right-4 bg-white/10 text-white rounded-full p-2 hover:bg-white/20 transition-colors"
            aria-label="Close"
          >
            <X size={24} />
          </button>
          <img
            src={fullScreenImage}
            alt="Full screen view"
            className="max-w-full max-h-full object-contain rounded-lg"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}

