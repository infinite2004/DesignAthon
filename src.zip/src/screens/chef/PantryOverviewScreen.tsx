import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, ChevronRight, Send, X } from 'lucide-react';
import { useAppStore } from '../../store/appStore';
import { Screen } from '../../components/layout/Screen';
import { Button } from '../../components/ui/Button';
import { TextField } from '../../components/forms/TextField';

export function PantryOverviewScreen() {
  const navigate = useNavigate();
  const inventory = useAppStore((state) => state.inventory);
  const mealPlan = useAppStore((state) => state.mealPlan);
  const [chatInput, setChatInput] = useState('');
  const [isChatExpanded, setIsChatExpanded] = useState(false);

  const expiringSoon = useMemo(() => {
    return inventory.filter(item => {
      if (!item.expiryDate) return false;
      const daysUntil = Math.floor(
        (new Date(item.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
      );
      return daysUntil <= 7 && daysUntil >= 0;
    });
  }, [inventory]);

  // Calculate meals left this week from meal plan
  const mealsLeftThisWeek = useMemo(() => {
    const today = new Date();
    const endOfWeek = new Date(today);
    endOfWeek.setDate(today.getDate() + (7 - today.getDay()));
    
    return mealPlan.filter(entry => {
      const entryDate = new Date(entry.date);
      return entryDate >= today && entryDate <= endOfWeek && !entry.cookedAt;
    }).length;
  }, [mealPlan]);

  const handleSurpriseMe = () => {
    // Navigate to AI recipes with "surprise me" flag
    navigate('/chef/ai-recipes', {
      state: { 
        surpriseMe: true,
        surpriseKey: Date.now(),
      },
    });
  };

  const handleFoodCategory = (category: string) => {
    // Navigate to AI recipes with the category as a query
    navigate('/chef/ai-recipes', {
      state: { 
        manualInput: category,
        recipeQuery: category,
        queryKey: Date.now(),
      },
    });
  };

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    
    // Navigate to AI recipes with the manual input
    navigate('/chef/ai-recipes', {
      state: { 
        manualInput: chatInput.trim(),
        recipeQuery: chatInput.trim(),
        queryKey: Date.now(),
      },
    });
    
    // Clear the input and collapse chat
    setChatInput('');
    setIsChatExpanded(false);
  };

  const handleChatExpand = () => {
    // Just toggle the expanded state, don't navigate
    setIsChatExpanded(true);
  };

  return (
    <Screen background="default">
      <div className="min-h-screen pb-32 safe-area-bottom">
        {/* Header */}
        <div className="px-4 pt-4 pb-2">
          <h1 className="text-2xl font-bold text-brand-brown">Cookd assistant</h1>
        </div>

        {/* Summary Statistics */}
        <div className="px-4 py-4">
          <div className="bg-brand-sage/30 rounded-2xl p-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-3xl font-bold text-brand-brown mb-1">{inventory.length}</p>
                <p className="text-xs text-brand-sage">items in stock</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-brand-brown mb-1">{expiringSoon.length}</p>
                <p className="text-xs text-brand-sage">items expiring</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-brand-brown mb-1">{mealsLeftThisWeek}</p>
                <p className="text-xs text-brand-sage">meals left this week</p>
              </div>
            </div>
          </div>
        </div>

        {/* Pantry Items */}
        <div className="px-4 py-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-brand-brown">Your Pantry</h2>
            <button
              onClick={() => navigate('/chef/pantry')}
              className="text-sm text-brand-teal hover:underline"
            >
              View All
            </button>
          </div>
          <div className="bg-brand-bg rounded-2xl p-4">
            {inventory.length > 0 ? (
              <>
                <div 
                  className="flex gap-3 overflow-x-auto no-scrollbar pb-2"
                  style={{
                    scrollbarWidth: 'none',
                    msOverflowStyle: 'none',
                    WebkitOverflowScrolling: 'touch',
                  }}
                >
                  {inventory.slice(0, 10).map((item) => (
                    <div
                      key={item.id}
                      className="text-center cursor-pointer select-none flex-shrink-0"
                      style={{ width: '80px' }}
                      onClick={() => navigate('/chef/pantry')}
                    >
                      <div className="w-16 h-16 bg-white rounded-xl mb-2 flex items-center justify-center relative overflow-hidden mx-auto border border-slate-200">
                        {item.imageUrl ? (
                          <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-10 h-10 bg-brand-sage/20 rounded-lg flex items-center justify-center">
                            <span className="text-2xl">🥫</span>
                          </div>
                        )}
                      </div>
                      <p className="text-xs font-medium text-brand-brown mb-0.5 truncate">
                        {item.name}
                      </p>
                      <p className="text-xs text-brand-sage">
                        {item.quantity} {item.unit}
                      </p>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => navigate('/chef/pantry')}
                  className="w-full mt-4 py-2.5 px-4 rounded-xl bg-brand-teal text-white text-sm font-semibold hover:bg-brand-teal/90 transition-colors flex items-center justify-center gap-2"
                >
                  <span>Go to Inventory</span>
                  <ChevronRight size={16} />
                </button>
              </>
            ) : (
              <div className="text-center py-8">
                <p className="text-sm text-brand-sage mb-4">Your pantry is empty</p>
                <button
                  onClick={() => navigate('/chef/pantry')}
                  className="py-2.5 px-4 rounded-xl bg-brand-teal text-white text-sm font-semibold hover:bg-brand-teal/90 transition-colors inline-flex items-center gap-2"
                >
                  <span>Add Items</span>
                  <ChevronRight size={16} />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* What do you want to eat? Section */}
        <div className="px-4 py-4">
          <h2 className="text-lg font-bold text-brand-teal mb-1">What do you want to eat?</h2>
          <p className="text-sm text-brand-sage mb-4">Ask for recipes you want to try.</p>
          
          <Button
            variant="primary"
            onClick={handleSurpriseMe}
            className="bg-brand-sage text-brand-bg rounded-xl px-4 py-2 mb-3 w-full"
          >
            Surprise Me!
          </Button>
          
          <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4">
            {['Italian', 'Asian', 'Mexican', 'Healthy'].map((category) => (
              <button
                key={category}
                onClick={() => handleFoodCategory(category)}
                className="px-4 py-2 bg-brand-sage/30 text-slate-800 rounded-xl text-sm font-medium whitespace-nowrap hover:bg-brand-sage/50 transition-colors flex-shrink-0"
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Mini Chat Window - Fixed at Bottom */}
        <div className="fixed bottom-20 left-0 right-0 px-4 pb-4 bg-gradient-to-t from-brand-beige via-brand-beige to-transparent pt-8 z-40">
          <div className={`w-full bg-white border-2 border-slate-300 rounded-2xl shadow-lg transition-all duration-300 ${
            isChatExpanded ? 'h-64' : 'h-auto'
          }`}>
            {isChatExpanded ? (
              // Expanded mini chat
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-3 border-b border-gray-200">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-brand-teal/20 flex items-center justify-center">
                      <Sparkles size={16} className="text-brand-teal" />
                    </div>
                    <span className="text-sm font-semibold text-slate-800">Cookd Assistant</span>
                  </div>
                  <button
                    onClick={() => setIsChatExpanded(false)}
                    className="p-1 hover:bg-gray-100 rounded-lg transition-colors"
                    aria-label="Minimize"
                  >
                    <X size={18} className="text-gray-600" />
                  </button>
                </div>
                
                <div className="flex-1 p-3 overflow-y-auto">
                  <div className="text-center text-sm text-gray-500 py-4">
                    <Sparkles size={20} className="mx-auto mb-2 text-brand-teal opacity-50" />
                    <p className="text-xs">Type your message below...</p>
                  </div>
                </div>
                
                <div className="p-3 border-t border-gray-200">
                  <div className="flex items-center gap-2">
                    <TextField
                      value={chatInput}
                      onChange={setChatInput}
                      placeholder="Ask me anything..."
                      onKeyPress={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      className="flex-1"
                    />
                    <button
                      onClick={handleSendMessage}
                      disabled={!chatInput.trim()}
                      className="p-2 bg-brand-teal text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed touch-target"
                      aria-label="Send message"
                    >
                      <Send size={18} />
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              // Collapsed button
              <button
                onClick={handleChatExpand}
                className="w-full p-4 text-left hover:border-brand-teal transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-brand-teal/20 flex items-center justify-center flex-shrink-0">
                    <Sparkles size={20} className="text-brand-teal" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-800">Chat with Cookd Assistant</p>
                    <p className="text-xs text-brand-sage mt-0.5">Ask for recipes, cooking tips, and more...</p>
                  </div>
                  <ChevronRight size={20} className="text-brand-sage" />
                </div>
              </button>
            )}
          </div>
        </div>
      </div>
    </Screen>
  );
}
