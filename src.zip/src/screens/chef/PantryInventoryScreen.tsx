import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Camera, Receipt, Edit3, Trash2 } from 'lucide-react';
import { useAppStore } from '../../store/appStore';
import { Screen } from '../../components/layout/Screen';
import type { InventoryItem } from '../../types';

export function PantryInventoryScreen() {
  const navigate = useNavigate();
  const inventory = useAppStore((state) => state.inventory);
  const deleteInventoryItem = useAppStore((state) => state.deleteInventoryItem);
  const [showAddMenu, setShowAddMenu] = useState(false);
  const [showManualEntry, setShowManualEntry] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);

  return (
    <Screen>
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/chef')}
            className="p-2 -ml-2 touch-target"
            aria-label="Go back"
          >
            <ArrowLeft size={24} className="text-gray-900" />
          </button>
          <h1 className="text-lg font-semibold text-gray-900">Pantry Inventory</h1>
        </div>
        <button
          onClick={() => setShowAddMenu(true)}
          className="p-2 bg-brand-teal text-white rounded-full hover:bg-brand-teal/90 transition-colors touch-target"
          aria-label="Add item"
        >
          <Plus size={20} />
        </button>
      </div>

      {/* Inventory List */}
      <div className="flex-1 overflow-y-auto pb-20">
        {inventory.length > 0 ? (
          <div className="p-4 space-y-3">
            {inventory.map((item) => (
              <div
                key={item.id}
                className="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3"
              >
                <div className="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden">
                  {item.imageUrl ? (
                    <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-3xl">🥫</span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900">{item.name}</h3>
                  <p className="text-sm text-gray-600">
                    {item.quantity} {item.unit} • {item.category}
                  </p>
                  {item.expiryDate && (
                    <p className="text-xs text-gray-500 mt-1">
                      Expires: {new Date(item.expiryDate).toLocaleDateString()}
                    </p>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setEditingItem(item)}
                    className="p-2 text-gray-400 hover:text-brand-teal touch-target"
                    aria-label="Edit item"
                  >
                    <Edit3 size={20} />
                  </button>
                  <button
                    onClick={() => deleteInventoryItem(item.id)}
                    className="p-2 text-gray-400 hover:text-red-500 touch-target"
                    aria-label="Delete item"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 px-4">
            <div className="w-20 h-20 bg-brand-sage/20 rounded-full flex items-center justify-center mb-4">
              <span className="text-4xl">🥫</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No items yet</h3>
            <p className="text-sm text-gray-600 text-center mb-6">
              Add items to your pantry to get started with recipe suggestions
            </p>
            <button
              onClick={() => setShowAddMenu(true)}
              className="py-2.5 px-6 rounded-xl bg-brand-teal text-white text-sm font-semibold hover:bg-brand-teal/90 transition-colors"
            >
              Add Your First Item
            </button>
          </div>
        )}
      </div>

      {/* Add Item Menu */}
      {showAddMenu && (
        <div
          className="fixed inset-0 bg-black/50 z-50 flex items-end"
          onClick={() => setShowAddMenu(false)}
        >
          <div
            className="bg-white rounded-t-3xl w-full p-6 space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Add Items</h2>
            
            <button
              onClick={() => {
                setShowAddMenu(false);
                navigate('/chef/fridge/capture');
              }}
              className="w-full flex items-center gap-4 p-4 rounded-xl border-2 border-slate-200 hover:border-brand-teal hover:bg-brand-teal/5 transition-all"
            >
              <div className="w-12 h-12 bg-brand-teal/10 rounded-full flex items-center justify-center">
                <Camera size={24} className="text-brand-teal" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-semibold text-gray-900">Scan Fridge</h3>
                <p className="text-sm text-gray-600">Use camera to detect items</p>
              </div>
            </button>

            <button
              onClick={() => {
                setShowAddMenu(false);
                navigate('/chef/receipt/capture');
              }}
              className="w-full flex items-center gap-4 p-4 rounded-xl border-2 border-slate-200 hover:border-brand-teal hover:bg-brand-teal/5 transition-all"
            >
              <div className="w-12 h-12 bg-brand-teal/10 rounded-full flex items-center justify-center">
                <Receipt size={24} className="text-brand-teal" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-semibold text-gray-900">Scan Receipt</h3>
                <p className="text-sm text-gray-600">Auto-add from purchase receipt</p>
              </div>
            </button>

            <button
              onClick={() => {
                setShowAddMenu(false);
                setShowManualEntry(true);
              }}
              className="w-full flex items-center gap-4 p-4 rounded-xl border-2 border-slate-200 hover:border-brand-teal hover:bg-brand-teal/5 transition-all"
            >
              <div className="w-12 h-12 bg-brand-teal/10 rounded-full flex items-center justify-center">
                <Edit3 size={24} className="text-brand-teal" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-semibold text-gray-900">Manual Entry</h3>
                <p className="text-sm text-gray-600">Type item details manually</p>
              </div>
            </button>

            <button
              onClick={() => setShowAddMenu(false)}
              className="w-full py-3 text-gray-600 font-medium"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Manual Entry Modal */}
      {showManualEntry && (
        <ManualEntryModal
          onClose={() => setShowManualEntry(false)}
        />
      )}

      {/* Edit Item Modal */}
      {editingItem && (
        <ManualEntryModal
          item={editingItem}
          onClose={() => setEditingItem(null)}
        />
      )}
    </Screen>
  );
}

function ManualEntryModal({ onClose, item }: { onClose: () => void; item?: InventoryItem }) {
  const addInventoryItem = useAppStore((state) => state.addInventoryItem);
  const updateInventoryItem = useAppStore((state) => state.updateInventoryItem);
  const [itemName, setItemName] = useState(item?.name || '');
  const [quantity, setQuantity] = useState(item?.quantity.toString() || '1');
  const [unit, setUnit] = useState(item?.unit || 'unit');
  const [category, setCategory] = useState<'fridge' | 'freezer' | 'pantry'>(item?.category || 'pantry');
  const [image, setImage] = useState(item?.imageUrl || '');
  const [expiryDate, setExpiryDate] = useState(
    item?.expiryDate 
      ? new Date(item.expiryDate).toISOString().split('T')[0] 
      : ''
  );

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (!itemName.trim()) return;

    if (item) {
      // Update existing item
      updateInventoryItem(item.id, {
        name: itemName.trim(),
        category,
        quantity: parseFloat(quantity) || 1,
        unit,
        location: category,
        imageUrl: image || undefined,
        expiryDate: expiryDate ? new Date(expiryDate) : undefined,
      });
    } else {
      // Add new item
      const newItem: InventoryItem = {
        id: crypto.randomUUID(),
        name: itemName.trim(),
        category,
        quantity: parseFloat(quantity) || 1,
        unit,
        location: category,
        imageUrl: image || undefined,
        expiryDate: expiryDate ? new Date(expiryDate) : undefined,
      };
      addInventoryItem(newItem);
    }
    
    onClose();
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl w-full max-w-md p-6 space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-xl font-semibold text-gray-900">
          {item ? 'Edit Item' : 'Add Item Manually'}
        </h2>

        {/* Item Name */}
        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">
            Item Name *
          </label>
          <input
            type="text"
            value={itemName}
            onChange={(e) => setItemName(e.target.value)}
            placeholder="e.g., Tomatoes, Milk, Rice..."
            className="w-full p-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-teal"
          />
        </div>

        {/* Image Upload */}
        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">
            Photo (Optional)
          </label>
          <input
            type="file"
            accept="image/*"
            onChange={handleImageSelect}
            className="hidden"
            id="item-image"
          />
          <label
            htmlFor="item-image"
            className="block w-full h-24 border-2 border-dashed border-slate-300 rounded-xl flex items-center justify-center cursor-pointer hover:border-brand-teal transition-colors"
          >
            {image ? (
              <img src={image} alt="Preview" className="h-full object-cover rounded-xl" />
            ) : (
              <div className="text-center">
                <Camera size={24} className="mx-auto text-gray-400 mb-1" />
                <p className="text-sm text-gray-600">Add photo</p>
              </div>
            )}
          </label>
        </div>

        {/* Quantity */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">
              Quantity *
            </label>
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              min="0"
              step="0.1"
              className="w-full p-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-teal"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">
              Unit *
            </label>
            <select
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              className="w-full p-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-teal bg-white"
            >
              <option value="unit">unit</option>
              <option value="g">g</option>
              <option value="kg">kg</option>
              <option value="ml">ml</option>
              <option value="L">L</option>
              <option value="cup">cup</option>
              <option value="tbsp">tbsp</option>
              <option value="tsp">tsp</option>
              <option value="lb">lb</option>
              <option value="oz">oz</option>
            </select>
          </div>
        </div>

        {/* Expiry Date */}
        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">
            Expiry Date (Optional)
          </label>
          <input
            type="date"
            value={expiryDate}
            onChange={(e) => setExpiryDate(e.target.value)}
            className="w-full p-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-teal"
          />
        </div>

        {/* Category */}
        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">
            Location *
          </label>
          <div className="flex gap-2">
            <button
              onClick={() => setCategory('fridge')}
              className={`flex-1 py-2 px-3 rounded-xl text-sm font-medium transition-all ${
                category === 'fridge'
                  ? 'bg-brand-teal text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Fridge
            </button>
            <button
              onClick={() => setCategory('freezer')}
              className={`flex-1 py-2 px-3 rounded-xl text-sm font-medium transition-all ${
                category === 'freezer'
                  ? 'bg-brand-teal text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Freezer
            </button>
            <button
              onClick={() => setCategory('pantry')}
              className={`flex-1 py-2 px-3 rounded-xl text-sm font-medium transition-all ${
                category === 'pantry'
                  ? 'bg-brand-teal text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Pantry
            </button>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-2">
          <button
            onClick={onClose}
            className="flex-1 py-3 px-4 rounded-xl bg-slate-100 text-slate-700 font-semibold hover:bg-slate-200 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!itemName.trim()}
            className="flex-1 py-3 px-4 rounded-xl bg-brand-teal text-white font-semibold hover:bg-brand-teal/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {item ? 'Update Item' : 'Add Item'}
          </button>
        </div>
      </div>
    </div>
  );
}
