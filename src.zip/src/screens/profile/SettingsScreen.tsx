import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, LogOut, Check, X } from 'lucide-react';
import { useAuth } from '../../providers/AuthProvider';
import { useToast } from '../../components/ui/ToastContext';
import { useAppStore } from '../../store/appStore';
import { Screen } from '../../components/layout/Screen';
import { Button } from '../../components/ui/Button';
import { TextField } from '../../components/forms/TextField';

const DIET_OPTIONS = [
  { value: 'vegan', label: 'Vegan', description: 'No animal products' },
  { value: 'vegetarian', label: 'Vegetarian', description: 'No meat or fish' },
  { value: 'keto', label: 'Keto', description: 'Low-carb, high-fat' },
  { value: 'paleo', label: 'Paleo', description: 'No grains, legumes, or dairy' },
];

const ALLERGY_OPTIONS = [
  { value: 'nuts', label: 'Nuts' },
  { value: 'dairy', label: 'Dairy' },
  { value: 'gluten', label: 'Gluten' },
  { value: 'shellfish', label: 'Shellfish' },
  { value: 'soy', label: 'Soy' },
  { value: 'eggs', label: 'Eggs' },
];

const RESTRICTION_OPTIONS = [
  { value: 'no-alcohol', label: 'No Alcohol' },
  { value: 'halal', label: 'Halal' },
  { value: 'kosher', label: 'Kosher' },
];

export function SettingsScreen() {
  const navigate = useNavigate();
  const { user, updateUser, logout } = useAuth();
  const { showToast } = useToast();
  const dietaryRestrictions = useAppStore((state) => state.dietaryRestrictions);
  const updateDietaryRestrictions = useAppStore((state) => state.updateDietaryRestrictions);
  
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [username, setUsername] = useState(user?.username || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [selectedDiets, setSelectedDiets] = useState<string[]>(dietaryRestrictions.diets);
  const [selectedAllergies, setSelectedAllergies] = useState<string[]>(dietaryRestrictions.allergies);
  const [selectedRestrictions, setSelectedRestrictions] = useState<string[]>(dietaryRestrictions.restrictions);
  const [customKeywords, setCustomKeywords] = useState<string[]>(dietaryRestrictions.customKeywords || []);
  const [newKeyword, setNewKeyword] = useState('');

  const toggleDiet = (diet: string) => {
    setSelectedDiets(prev =>
      prev.includes(diet) ? prev.filter(d => d !== diet) : [...prev, diet]
    );
  };

  const toggleAllergy = (allergy: string) => {
    setSelectedAllergies(prev =>
      prev.includes(allergy) ? prev.filter(a => a !== allergy) : [...prev, allergy]
    );
  };

  const toggleRestriction = (restriction: string) => {
    setSelectedRestrictions(prev =>
      prev.includes(restriction) ? prev.filter(r => r !== restriction) : [...prev, restriction]
    );
  };

  const addKeyword = () => {
    const trimmed = newKeyword.trim();
    if (trimmed && !customKeywords.includes(trimmed.toLowerCase())) {
      setCustomKeywords([...customKeywords, trimmed.toLowerCase()]);
      setNewKeyword('');
    }
  };

  const removeKeyword = (keyword: string) => {
    setCustomKeywords(customKeywords.filter(k => k !== keyword));
  };

  const handleSave = async () => {
    try {
      await updateUser({
        displayName,
        username,
        bio,
      });
      
      // Save dietary restrictions
      updateDietaryRestrictions({
        diets: selectedDiets,
        allergies: selectedAllergies,
        restrictions: selectedRestrictions,
        customKeywords: customKeywords,
      });
      
      showToast('Settings saved successfully!', 'success');
      navigate(-1);
    } catch (err) {
      showToast('Failed to update settings', 'error');
    }
  };

  const handleLogout = async () => {
    if (window.confirm('Are you sure you want to sign out?')) {
      await logout();
      navigate('/login', { replace: true });
    }
  };

  return (
    <Screen>
      <header className="sticky top-0 z-40 bg-white border-b border-gray-200 safe-area-top">
        <div className="flex items-center justify-between px-4 py-3">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 touch-target"
            aria-label="Back"
          >
            <ArrowLeft size={24} className="text-gray-600" />
          </button>
          <h1 className="text-sm font-semibold text-teal">Settings</h1>
          <div className="w-8" />
        </div>
      </header>

      <div className="px-4 py-6 space-y-6">
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-gray-900">Profile Information</h2>
          <TextField
            label="Display Name"
            value={displayName}
            onChange={setDisplayName}
          />
          <TextField
            label="Username"
            value={username}
            onChange={setUsername}
          />
          <TextField
            label="Bio"
            value={bio}
            onChange={setBio}
            multiline
            rows={4}
          />
        </div>

        {/* Dietary Preferences */}
        <div className="space-y-4 pt-4 border-t border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Dietary Preferences</h2>
          <p className="text-sm text-gray-600">
            These settings help us suggest recipes that match your diet and alert you to potential violations.
          </p>

          {/* Diets */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Diet Type</h3>
            <div className="grid grid-cols-2 gap-2">
              {DIET_OPTIONS.map((diet) => (
                <button
                  key={diet.value}
                  onClick={() => toggleDiet(diet.value)}
                  className={`p-3 rounded-xl border-2 text-left transition-all ${
                    selectedDiets.includes(diet.value)
                      ? 'border-brand-teal bg-brand-teal/10'
                      : 'border-gray-200 bg-white'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="font-medium text-sm">{diet.label}</p>
                      <p className="text-xs text-gray-600 mt-0.5">{diet.description}</p>
                    </div>
                    {selectedDiets.includes(diet.value) && (
                      <Check size={16} className="text-brand-teal flex-shrink-0 ml-2" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Allergies */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Allergies</h3>
            <div className="flex flex-wrap gap-2">
              {ALLERGY_OPTIONS.map((allergy) => (
                <button
                  key={allergy.value}
                  onClick={() => toggleAllergy(allergy.value)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                    selectedAllergies.includes(allergy.value)
                      ? 'bg-red-100 text-red-700 border-2 border-red-300'
                      : 'bg-gray-100 text-gray-700 border-2 border-transparent'
                  }`}
                >
                  {allergy.label}
                  {selectedAllergies.includes(allergy.value) && ' ⚠️'}
                </button>
              ))}
            </div>
          </div>

          {/* Other Restrictions */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Other Restrictions</h3>
            <div className="flex flex-wrap gap-2">
              {RESTRICTION_OPTIONS.map((restriction) => (
                <button
                  key={restriction.value}
                  onClick={() => toggleRestriction(restriction.value)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                    selectedRestrictions.includes(restriction.value)
                      ? 'bg-brand-teal text-white'
                      : 'bg-gray-100 text-gray-700 border-2 border-transparent'
                  }`}
                >
                  {restriction.label}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Keywords to Avoid */}
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Custom Ingredients to Avoid</h3>
            <p className="text-xs text-gray-600 mb-3">
              Add specific ingredients or keywords you want to avoid (e.g., "mushrooms", "cilantro", "pickles")
            </p>
            
            {/* Input to add new keyword */}
            <div className="flex gap-2 mb-3">
              <input
                type="text"
                value={newKeyword}
                onChange={(e) => setNewKeyword(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addKeyword()}
                placeholder="Add keyword..."
                className="flex-1 px-3 py-2 border-2 border-gray-200 rounded-lg text-sm focus:outline-none focus:border-brand-teal"
              />
              <button
                onClick={addKeyword}
                className="px-4 py-2 bg-brand-teal text-white rounded-lg text-sm font-medium hover:bg-brand-teal/90"
              >
                Add
              </button>
            </div>

            {/* Display custom keywords */}
            {customKeywords.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {customKeywords.map((keyword, idx) => (
                  <div
                    key={idx}
                    className="px-3 py-1.5 bg-orange-100 text-orange-700 rounded-full text-sm font-medium flex items-center gap-2"
                  >
                    {keyword}
                    <button
                      onClick={() => removeKeyword(keyword)}
                      className="hover:bg-orange-200 rounded-full p-0.5"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="pt-4">
          <Button
            variant="primary"
            fullWidth
            onClick={handleSave}
            className="rounded-2xl"
          >
            Save Changes
          </Button>
        </div>

        <div className="pt-8 border-t border-gray-200">
          <Button
            variant="danger"
            fullWidth
            onClick={handleLogout}
            iconLeft={<LogOut size={18} />}
            className="rounded-2xl"
          >
            Sign Out
          </Button>
        </div>
      </div>
    </Screen>
  );
}

