import { useNavigate } from 'react-router-dom';
import { ArrowLeft, MessageCircle } from 'lucide-react';
import { useAppStore } from '../../store/appStore';
import { useAuth } from '../../providers/AuthProvider';
import { formatTimeAgo } from '../../lib/utils';
import { Avatar } from '../../components/media/Avatar';

export function DMListScreen() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const conversations = useAppStore((state) => state.conversations);

  // Sort conversations by most recent
  const sortedConversations = [...conversations].sort(
    (a, b) => b.updatedAt.getTime() - a.updatedAt.getTime()
  );

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-slate-200 px-4 py-3 flex items-center gap-3 z-10">
        <button
          onClick={() => navigate('/feed')}
          className="p-2 -ml-2 touch-target"
          aria-label="Back to feed"
        >
          <ArrowLeft size={24} className="text-slate-900" />
        </button>
        <h1 className="text-lg font-semibold text-slate-900">Messages</h1>
      </div>

      {/* Conversations List */}
      <div className="divide-y divide-slate-200 pb-24">
        {sortedConversations.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 px-4">
            <MessageCircle size={48} className="text-slate-300 mb-4" />
            <p className="text-slate-500 text-center">No messages yet</p>
            <p className="text-slate-400 text-sm text-center mt-2">
              Start a conversation by requesting a recipe from a post!
            </p>
          </div>
        ) : (
          sortedConversations.map((conversation) => {
            const otherUser = conversation.participantDetails.find(
              (p) => p.id !== user?.id
            ) || conversation.participantDetails[0];

            const unreadCount = conversation.lastMessage && !conversation.lastMessage.isRead
              ? 1
              : 0;

            return (
              <button
                key={conversation.id}
                onClick={() => navigate(`/messages/${conversation.id}`)}
                className="w-full px-4 py-4 flex items-start gap-3 hover:bg-slate-50 active:bg-slate-100 transition-colors touch-target text-left"
              >
                <Avatar
                  src={otherUser.avatar}
                  initials={otherUser.displayName[0]}
                  size={48}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-semibold text-sm truncate">
                      {otherUser.displayName}
                    </h3>
                    {conversation.lastMessage && (
                      <span className="text-xs text-slate-500 ml-2 flex-shrink-0">
                        {formatTimeAgo(conversation.lastMessage.createdAt)}
                      </span>
                    )}
                  </div>
                  
                  {conversation.postPreview && (
                    <p className="text-xs text-slate-500 truncate mb-1">
                      About: {conversation.postPreview.caption}
                    </p>
                  )}

                  {conversation.lastMessage && (
                    <p
                      className={`text-sm truncate ${
                        unreadCount > 0
                          ? 'font-semibold text-slate-900'
                          : 'text-slate-600'
                      }`}
                    >
                      {conversation.lastMessage.senderId === user?.id && 'You: '}
                      {conversation.lastMessage.content}
                    </p>
                  )}
                </div>

                {unreadCount > 0 && (
                  <div className="w-2 h-2 bg-brand-teal rounded-full flex-shrink-0 mt-2" />
                )}
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}
