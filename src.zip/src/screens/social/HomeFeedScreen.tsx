import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageCircle } from 'lucide-react';
import { Screen } from '../../components/layout/Screen';
import { PostList } from '../../components/social/PostList';
import { useFeedQuery } from '../../hooks/useFeed';
import { useAppStore } from '../../store/appStore';
import { useAuth } from '../../providers/AuthProvider';
import { PullToRefresh } from '../../components/ui/PullToRefresh';
import { useDailyCookdNotifications } from '../../hooks/useDailyCookdNotifications';

export function HomeFeedScreen() {
  const navigate = useNavigate();
  const { data: apiPosts, isLoading, isError, refetch } = useFeedQuery();
  const storePosts = useAppStore((state) => state.posts);
  const conversations = useAppStore((state) => state.conversations);
  const followingUsers = useAppStore((state) => state.followingUsers);
  const { user } = useAuth();
  
  // Enable daily Cook'd notifications
  useDailyCookdNotifications();
  
  // Count unread messages
  const unreadCount = conversations.filter(
    conv => conv.lastMessage && !conv.lastMessage.isRead
  ).length;
  
  // Filter and display posts
  const displayPosts = useMemo(() => {
    const allPostIds = new Set(storePosts.map(p => p.id));
    const additionalApiPosts = apiPosts?.filter(p => !allPostIds.has(p.id)) || [];
    const allPosts = [...storePosts, ...additionalApiPosts].sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    // Filter posts:
    // 1. Only show meal posts, no tips
    // 2. Show posts from users you're following
    // 3. Show your own recent posts (last 5 minutes)
    return allPosts.filter((post) => {
      // Only show meal posts, no tips
      if (post.type !== 'meal') return false;
      
      if (!user) return true;
      
      const isOwnPost = post.userId === user.id || post.user.username === user.username;
      
      // Show own posts if recent (last 5 minutes)
      if (isOwnPost) {
        const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
        const isRecent = new Date(post.createdAt).getTime() > fiveMinutesAgo;
        return isRecent;
      }
      
      // Show posts from users you're following
      return followingUsers.includes(post.userId);
    });
  }, [storePosts, apiPosts, user, followingUsers]);

  const handleRefresh = async () => {
    await refetch();
  };

  return (
    <Screen>
      {/* Header with Cookd Logo and Messages Button */}
      <div className="sticky top-0 z-40 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-center relative">
        <h1 className="text-xl font-bold text-brand-teal" style={{ fontFamily: 'Madimi One, cursive' }}>Cookd</h1>
        <button
          onClick={() => navigate('/messages')}
          className="absolute right-4 p-2 touch-target"
          aria-label="Messages"
        >
          <MessageCircle size={24} className="text-slate-900" />
          {unreadCount > 0 && (
            <div className="absolute top-1 right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
              <span className="text-xs text-white font-semibold">{unreadCount}</span>
            </div>
          )}
        </button>
      </div>

      <div className="bg-brand-bg min-h-screen">
        <PullToRefresh onRefresh={handleRefresh}>
          <PostList
            posts={displayPosts}
            isLoading={isLoading && storePosts.length === 0}
            isError={isError && storePosts.length === 0}
            onRetry={() => refetch()}
          />
        </PullToRefresh>
      </div>
    </Screen>
  );
}

