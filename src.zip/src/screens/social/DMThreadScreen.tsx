import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Send } from 'lucide-react';
import { useAuth } from '../../providers/AuthProvider';
import { useAppStore } from '../../store/appStore';
import { formatTimeAgo } from '../../lib/utils';
import { Avatar } from '../../components/media/Avatar';

export function DMThreadScreen() {
  const { conversationId } = useParams<{ conversationId: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  
  const conversations = useAppStore((state) => state.conversations);
  const getConversationMessages = useAppStore((state) => state.getConversationMessages);
  const sendMessage = useAppStore((state) => state.sendMessage);
  
  const [messageText, setMessageText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const conversation = conversations.find(c => c.id === conversationId);
  const messages = conversationId ? getConversationMessages(conversationId) : [];
  
  const otherUser = conversation?.participantDetails.find(p => p.id !== user?.id) 
    || conversation?.participantDetails[0];

  // Auto-populate initial message if coming from request recipe
  useEffect(() => {
    const initialMessage = location.state?.initialMessage;
    if (initialMessage) {
      setMessageText(initialMessage);
    }
  }, [location.state]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Mark messages as read when viewing conversation
  useEffect(() => {
    if (conversationId && conversation?.lastMessage && !conversation.lastMessage.isRead) {
      // Mark the last message as read
      const updatedConversations = conversations.map(conv => {
        if (conv.id === conversationId && conv.lastMessage) {
          return {
            ...conv,
            lastMessage: {
              ...conv.lastMessage,
              isRead: true,
            },
          };
        }
        return conv;
      });
      
      // Update store
      useAppStore.setState({ conversations: updatedConversations });
      
      // Persist to localStorage
      try {
        localStorage.setItem('cookd_conversations', JSON.stringify(updatedConversations));
      } catch (error) {
        console.error('Error saving conversations:', error);
      }
    }
  }, [conversationId, conversation, conversations]);

  const handleSend = () => {
    if (!messageText.trim() || !conversationId) return;
    sendMessage(conversationId, messageText);
    setMessageText('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!conversation || !otherUser) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white">
        <p className="text-slate-500">Conversation not found</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-white">
      {/* Header - Fixed */}
      <div className="flex-shrink-0 bg-white border-b border-slate-200 px-4 py-3 flex items-center gap-3 z-10">
        <button
          onClick={() => navigate('/messages')}
          className="p-2 -ml-2 touch-target"
          aria-label="Back to messages"
        >
          <ArrowLeft size={24} className="text-slate-900" />
        </button>
        <Avatar
          src={otherUser.avatar}
          initials={otherUser.displayName[0]}
          size={40}
        />
        <div className="flex-1 min-w-0">
          <h1 className="text-sm font-semibold text-slate-900 truncate">
            {otherUser.displayName}
          </h1>
          <p className="text-xs text-slate-500">@{otherUser.username}</p>
        </div>
      </div>

      {/* Post Preview (if applicable) */}
      {conversation.postPreview && (
        <div className="flex-shrink-0 p-3 bg-brand-bg border-b border-slate-200">
          <div className="flex items-center gap-3">
            {conversation.postPreview.image && (
              <img
                src={conversation.postPreview.image}
                alt="Post"
                className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
              />
            )}
            <div className="flex-1 min-w-0">
              <p className="text-xs text-slate-500 mb-1">About this recipe:</p>
              <p className="text-sm text-slate-900 line-clamp-2">
                {conversation.postPreview.caption}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Messages - Scrollable */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
        {messages.map((message) => {
          const isOwn = message.senderId === user?.id;
          
          return (
            <div
              key={message.id}
              className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
            >
              <div className="flex items-end gap-2 max-w-[80%]">
                {!isOwn && (
                  <Avatar
                    src={otherUser.avatar}
                    initials={otherUser.displayName[0]}
                    size={32}
                    className="flex-shrink-0"
                  />
                )}
                <div>
                  <div
                    className={`rounded-2xl px-4 py-2.5 ${
                      isOwn
                        ? 'bg-brand-teal text-white'
                        : 'bg-white text-slate-900 border border-slate-200'
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap break-words leading-relaxed">
                      {message.content}
                    </p>
                  </div>
                  <p className={`text-xs text-slate-500 mt-1 ${isOwn ? 'text-right' : 'text-left'}`}>
                    {formatTimeAgo(message.createdAt)}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input - Fixed at Bottom */}
      <div className="flex-shrink-0 border-t border-slate-200 bg-white px-4 py-3 safe-area-bottom">
        <div className="flex items-end gap-2">
          <textarea
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type a message..."
            className="flex-1 min-h-[44px] max-h-32 p-3 bg-white border border-slate-300 rounded-2xl resize-none focus:outline-none focus:ring-2 focus:ring-brand-teal focus:border-transparent"
            rows={1}
          />
          <button
            onClick={handleSend}
            disabled={!messageText.trim()}
            className={`p-3 rounded-full touch-target flex-shrink-0 transition-colors ${
              messageText.trim()
                ? 'bg-brand-teal text-white'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
            aria-label="Send message"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
