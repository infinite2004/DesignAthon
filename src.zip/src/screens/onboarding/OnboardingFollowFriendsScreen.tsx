import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check } from 'lucide-react';
import { useAppStore } from '../../store/appStore';
import { Screen } from '../../components/layout/Screen';
import { Button } from '../../components/ui/Button';
import { Avatar } from '../../components/media/Avatar';

// Mock suggested users
const SUGGESTED_USERS = [
  {
    id: '2',
    username: 'budgetchef',
    displayName: 'Budget Chef',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=budgetchef',
    bio: 'Cooking on a budget 💰',
    followers: 234,
  },
  {
    id: '3',
    username: 'healthykitchen',
    displayName: 'Healthy Kitchen',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=healthykitchen',
    bio: 'Plant-based recipes 🌱',
    followers: 567,
  },
  {
    id: '4',
    username: 'quickmeals',
    displayName: 'Quick Meals',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=quickmeals',
    bio: '30-minute meals ⏰',
    followers: 412,
  },
  {
    id: '5',
    username: 'bakeryboss',
    displayName: 'Bakery Boss',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=bakeryboss',
    bio: 'Bread and pastries 🥖',
    followers: 891,
  },
  {
    id: '6',
    username: 'spicylife',
    displayName: 'Spicy Life',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=spicylife',
    bio: 'Spicy food lover 🌶️',
    followers: 345,
  },
  {
    id: '7',
    username: 'mealprep',
    displayName: 'Meal Prep Pro',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mealprep',
    bio: 'Meal prep for the week 📦',
    followers: 678,
  },
];

export function OnboardingFollowFriendsScreen() {
  const navigate = useNavigate();
  const followUser = useAppStore((state) => state.followUser);
  const followingUsers = useAppStore((state) => state.followingUsers);
  const [localFollowing, setLocalFollowing] = useState<string[]>(followingUsers);

  const toggleFollow = (userId: string) => {
    if (localFollowing.includes(userId)) {
      setLocalFollowing(localFollowing.filter(id => id !== userId));
    } else {
      setLocalFollowing([...localFollowing, userId]);
      followUser(userId);
    }
  };

  const handleContinue = () => {
    // Make sure all follows are saved
    localFollowing.forEach(userId => {
      if (!followingUsers.includes(userId)) {
        followUser(userId);
      }
    });
    
    // Mark that the user has completed onboarding (sets flag for grocery/recipe cleanup)
    localStorage.setItem('cookd_has_logged_in', 'true');
    
    // Navigate to home
    navigate('/home');
  };

  const handleSkip = () => {
    // Mark that the user has completed onboarding
    localStorage.setItem('cookd_has_logged_in', 'true');
    
    navigate('/home');
  };

  return (
    <Screen>
      <div className="flex flex-col h-screen bg-brand-bg">
        {/* Header */}
        <div className="px-4 pt-8 pb-4">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Find Friends</h1>
              <p className="text-sm text-gray-600 mt-1">Follow creators to see their recipes</p>
            </div>
            <button
              onClick={handleSkip}
              className="text-sm text-brand-teal font-medium"
            >
              Skip
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-4 pb-24">
          <div className="space-y-3">
            {SUGGESTED_USERS.map((user) => {
              const isFollowing = localFollowing.includes(user.id);
              
              return (
                <div
                  key={user.id}
                  className="bg-white rounded-xl p-4 border border-gray-200"
                >
                  <div className="flex items-center gap-3">
                    <Avatar
                      src={user.avatar}
                      initials={user.displayName.split(' ').map(n => n[0]).join('')}
                      size={48}
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-sm truncate">{user.displayName}</h3>
                      <p className="text-xs text-gray-600 truncate">@{user.username}</p>
                      <p className="text-xs text-gray-500 mt-1">{user.bio}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{user.followers} followers</p>
                    </div>
                    <button
                      onClick={() => toggleFollow(user.id)}
                      className={`px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-1 ${
                        isFollowing
                          ? 'bg-brand-teal/10 text-brand-teal border-2 border-brand-teal'
                          : 'bg-brand-teal text-white'
                      }`}
                    >
                      {isFollowing && <Check size={16} />}
                      {isFollowing ? 'Following' : 'Follow'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Fixed Bottom Button */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 safe-area-bottom">
          <Button
            variant="primary"
            fullWidth
            onClick={handleContinue}
            className="rounded-2xl"
          >
            {localFollowing.length > 0 
              ? `Continue (Following ${localFollowing.length})`
              : 'Continue'
            }
          </Button>
        </div>
      </div>
    </Screen>
  );
}
