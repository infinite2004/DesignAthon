import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, X } from 'lucide-react';
import { useAppStore } from '../../store/appStore';
import { Screen } from '../../components/layout/Screen';
import { Button } from '../../components/ui/Button';

const DIET_OPTIONS = [
  { value: 'vegan', label: 'Vegan', description: 'No animal products' },
  { value: 'vegetarian', label: 'Vegetarian', description: 'No meat or fish' },
  { value: 'keto', label: 'Keto', description: 'Low-carb, high-fat' },
  { value: 'paleo', label: 'Paleo', description: 'No grains, legumes, or dairy' },
];

const ALLERGY_OPTIONS = [
  { value: 'nuts', label: 'Nuts' },
  { value: 'dairy', label: 'Dairy' },
  { value: 'gluten', label: 'Gluten' },
  { value: 'shellfish', label: 'Shellfish' },
  { value: 'soy', label: 'Soy' },
  { value: 'eggs', label: 'Eggs' },
];

const RESTRICTION_OPTIONS = [
  { value: 'no-alcohol', label: 'No Alcohol' },
  { value: 'halal', label: 'Halal' },
  { value: 'kosher', label: 'Kosher' },
];

export function OnboardingDietaryRestrictionsScreen() {
  const navigate = useNavigate();
  const updateDietaryRestrictions = useAppStore((state) => state.updateDietaryRestrictions);
  
  const [selectedDiets, setSelectedDiets] = useState<string[]>([]);
  const [selectedAllergies, setSelectedAllergies] = useState<string[]>([]);
  const [selectedRestrictions, setSelectedRestrictions] = useState<string[]>([]);
  const [customKeywords, setCustomKeywords] = useState<string[]>([]);
  const [newKeyword, setNewKeyword] = useState('');

  const toggleDiet = (diet: string) => {
    setSelectedDiets(prev =>
      prev.includes(diet) ? prev.filter(d => d !== diet) : [...prev, diet]
    );
  };

  const toggleAllergy = (allergy: string) => {
    setSelectedAllergies(prev =>
      prev.includes(allergy) ? prev.filter(a => a !== allergy) : [...prev, allergy]
    );
  };

  const toggleRestriction = (restriction: string) => {
    setSelectedRestrictions(prev =>
      prev.includes(restriction) ? prev.filter(r => r !== restriction) : [...prev, restriction]
    );
  };

  const addKeyword = () => {
    const trimmed = newKeyword.trim();
    if (trimmed && !customKeywords.includes(trimmed.toLowerCase())) {
      setCustomKeywords([...customKeywords, trimmed.toLowerCase()]);
      setNewKeyword('');
    }
  };

  const removeKeyword = (keyword: string) => {
    setCustomKeywords(customKeywords.filter(k => k !== keyword));
  };

  const handleContinue = () => {
    // Save dietary restrictions
    updateDietaryRestrictions({
      diets: selectedDiets,
      allergies: selectedAllergies,
      restrictions: selectedRestrictions,
      customKeywords: customKeywords,
    });
    
    // Navigate to follow friends screen
    navigate('/onboarding/follow-friends');
  };

  const handleSkip = () => {
    navigate('/onboarding/follow-friends');
  };

  return (
    <Screen>
      <div className="flex flex-col h-screen bg-brand-bg">
        {/* Header */}
        <div className="px-4 pt-8 pb-4">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Dietary Preferences</h1>
              <p className="text-sm text-gray-600 mt-1">Help us personalize your recipe suggestions</p>
            </div>
            <button
              onClick={handleSkip}
              className="text-sm text-brand-teal font-medium"
            >
              Skip
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-4 pb-24">
          <div className="space-y-6">
            {/* Diets */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-3">Diet Type</h3>
              <div className="grid grid-cols-2 gap-3">
                {DIET_OPTIONS.map((diet) => (
                  <button
                    key={diet.value}
                    onClick={() => toggleDiet(diet.value)}
                    className={`p-3 rounded-xl border-2 text-left transition-all ${
                      selectedDiets.includes(diet.value)
                        ? 'border-brand-teal bg-brand-teal/10'
                        : 'border-gray-200 bg-white'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{diet.label}</p>
                        <p className="text-xs text-gray-600 mt-0.5">{diet.description}</p>
                      </div>
                      {selectedDiets.includes(diet.value) && (
                        <Check size={16} className="text-brand-teal flex-shrink-0 ml-2" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Allergies */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-3">Allergies</h3>
              <p className="text-xs text-gray-600 mb-3">We'll alert you when recipes contain these ingredients</p>
              <div className="flex flex-wrap gap-2">
                {ALLERGY_OPTIONS.map((allergy) => (
                  <button
                    key={allergy.value}
                    onClick={() => toggleAllergy(allergy.value)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      selectedAllergies.includes(allergy.value)
                        ? 'bg-red-100 text-red-700 border-2 border-red-300'
                        : 'bg-gray-100 text-gray-700 border-2 border-transparent'
                    }`}
                  >
                    {allergy.label}
                    {selectedAllergies.includes(allergy.value) && ' ⚠️'}
                  </button>
                ))}
              </div>
            </div>

            {/* Other Restrictions */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-3">Other Restrictions</h3>
              <div className="flex flex-wrap gap-2">
                {RESTRICTION_OPTIONS.map((restriction) => (
                  <button
                    key={restriction.value}
                    onClick={() => toggleRestriction(restriction.value)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      selectedRestrictions.includes(restriction.value)
                        ? 'bg-brand-teal text-white'
                        : 'bg-gray-100 text-gray-700 border-2 border-transparent'
                    }`}
                  >
                    {restriction.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Keywords */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">Custom Ingredients to Avoid</h3>
              <p className="text-xs text-gray-600 mb-3">
                Add specific ingredients you don't like (e.g., "mushrooms", "cilantro")
              </p>
              
              {/* Input */}
              <div className="flex gap-2 mb-3">
                <input
                  type="text"
                  value={newKeyword}
                  onChange={(e) => setNewKeyword(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addKeyword()}
                  placeholder="Add ingredient..."
                  className="flex-1 px-3 py-2 border-2 border-gray-200 rounded-lg text-sm focus:outline-none focus:border-brand-teal"
                />
                <button
                  onClick={addKeyword}
                  className="px-4 py-2 bg-brand-teal text-white rounded-lg text-sm font-medium hover:bg-brand-teal/90"
                >
                  Add
                </button>
              </div>

              {/* Display keywords */}
              {customKeywords.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {customKeywords.map((keyword, idx) => (
                    <div
                      key={idx}
                      className="px-3 py-1.5 bg-orange-100 text-orange-700 rounded-full text-sm font-medium flex items-center gap-2"
                    >
                      {keyword}
                      <button
                        onClick={() => removeKeyword(keyword)}
                        className="hover:bg-orange-200 rounded-full p-0.5"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Fixed Bottom Button */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 safe-area-bottom">
          <Button
            variant="primary"
            fullWidth
            onClick={handleContinue}
            className="rounded-2xl"
          >
            Continue
          </Button>
        </div>
      </div>
    </Screen>
  );
}
