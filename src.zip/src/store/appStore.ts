import { create } from 'zustand';
import type { User, Post, Recipe, InventoryItem, MealPlanEntry, GroceryItem, Comment } from '../types';
import type { DMConversation, DMMessage } from '../types/messaging';

interface AppState {
  currentUser: User | null;
  posts: Post[];
  comments: Comment[];
  recipes: Recipe[];
  inventory: InventoryItem[];
  mealPlan: MealPlanEntry[];
  groceryList: GroceryItem[];
  savedPosts: string[];
  savedRecipes: string[];
  followingUsers: string[]; // Array of user IDs that current user follows
  conversations: DMConversation[];
  messages: DMMessage[];
  dietaryRestrictions: {
    diets: string[];
    allergies: string[];
    restrictions: string[];
    customKeywords: string[];
  };
  
  // Actions
  setCurrentUser: (user: User) => void;
  followUser: (userId: string) => void;
  unfollowUser: (userId: string) => void;
  addPost: (post: Post) => void;
  likePost: (postId: string) => void;
  addComment: (comment: Comment) => void;
  reCookPost: (postId: string) => void;
  savePost: (postId: string) => void;
  unsavePost: (postId: string) => void;
  saveRecipe: (recipeId: string) => void;
  unsaveRecipe: (recipeId: string) => void;
  reactToPost: (postId: string, reaction: 'youCooked' | 'youreCooked') => void;
  removeReaction: (postId: string) => void;
  addInventoryItem: (item: InventoryItem) => void;
  updateInventoryItem: (id: string, updates: Partial<InventoryItem>) => void;
  deleteInventoryItem: (id: string) => void;
  deductIngredientsFromInventory: (ingredients: { name: string; amount: number; unit: string }[]) => void;
  checkMissingIngredients: (ingredients: { name: string; amount: number; unit: string }[]) => { missing: { name: string; amount: number; unit: string }[]; hasAll: boolean };
  addMealPlanEntry: (entry: MealPlanEntry) => void;
  updateMealPlanEntry: (id: string, updates: Partial<MealPlanEntry>) => void;
  addGroceryItem: (item: GroceryItem) => void;
  toggleGroceryItem: (id: string) => void;
  deleteGroceryItem: (id: string) => void;
  clearGroceryList: () => void;
  addRecipe: (recipe: Recipe) => void;
  getOrCreateConversation: (otherUserId: string, postId?: string) => string;
  sendMessage: (conversationId: string, content: string) => void;
  getConversationMessages: (conversationId: string) => DMMessage[];
  updateDietaryRestrictions: (restrictions: { diets?: string[]; allergies?: string[]; restrictions?: string[]; customKeywords?: string[] }) => void;
  checkRecipeViolations: (recipe: Recipe) => { violates: boolean; violations: string[] };
}

// Mock data generator
const generateMockUser = (): User => ({
  id: '1',
  username: 'cookmaster',
  displayName: 'Chef Alex',
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex',
  bio: 'Love cooking on a budget! 🍳',
  followers: 1234,
  following: 567,
  mealsShared: 89,
  wasteReduced: 12500,
  avgCostPerServing: 2.45,
  badges: [],
});

const generateMockPosts = (): Post[] => {
  const users: User[] = [
    generateMockUser(),
    {
      id: '2',
      username: 'budgetchef',
      displayName: 'Budget Chef',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=budgetchef',
      bio: 'Cooking on a budget 💰',
      followers: 234,
      following: 180,
      mealsShared: 45,
      wasteReduced: 8900,
      avgCostPerServing: 1.95,
      badges: [],
    },
    {
      id: '3',
      username: 'healthykitchen',
      displayName: 'Healthy Kitchen',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=healthykitchen',
      bio: 'Plant-based recipes 🌱',
      followers: 567,
      following: 290,
      mealsShared: 87,
      wasteReduced: 12500,
      avgCostPerServing: 2.10,
      badges: [],
    },
    {
      id: '4',
      username: 'quickmeals',
      displayName: 'Quick Meals',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=quickmeals',
      bio: '30-minute meals ⏰',
      followers: 412,
      following: 220,
      mealsShared: 156,
      wasteReduced: 25000,
      avgCostPerServing: 2.75,
      badges: [],
    },
    {
      id: '5',
      username: 'bakeryboss',
      displayName: 'Bakery Boss',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=bakeryboss',
      bio: 'Bread and pastries 🥖',
      followers: 891,
      following: 340,
      mealsShared: 203,
      wasteReduced: 34000,
      avgCostPerServing: 3.25,
      badges: [],
    },
    {
      id: '6',
      username: 'spicylife',
      displayName: 'Spicy Life',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=spicylife',
      bio: 'Spicy food lover 🌶️',
      followers: 345,
      following: 195,
      mealsShared: 98,
      wasteReduced: 15000,
      avgCostPerServing: 2.45,
      badges: [],
    },
    {
      id: '7',
      username: 'mealprep',
      displayName: 'Meal Prep Pro',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mealprep',
      bio: 'Meal prep for the week 📦',
      followers: 678,
      following: 310,
      mealsShared: 134,
      wasteReduced: 21000,
      avgCostPerServing: 2.15,
      badges: [],
    },
  ];

  return [
    // Budget Chef posts
    {
      id: 'mock-1',
      userId: '2',
      user: users[1],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400'],
      caption: 'Made this amazing chickpea curry using spinach and tomatoes that were about to expire! Zero waste win 🎉 Cost only $2.50 per serving!',
      recipeId: 'recipe-mock-1',
      recipe: {
        id: 'recipe-mock-1',
        userId: '2',
        title: 'Zero-Waste Chickpea Curry',
        description: 'A delicious curry that uses up expiring vegetables',
        ingredients: [
          { id: '1', name: 'Chickpeas', amount: 1, unit: 'can' },
          { id: '2', name: 'Spinach', amount: 2, unit: 'cups' },
          { id: '3', name: 'Tomatoes', amount: 2, unit: 'medium' },
          { id: '4', name: 'Curry powder', amount: 2, unit: 'tbsp' },
          { id: '5', name: 'Coconut milk', amount: 1, unit: 'can' },
        ],
        steps: [
          'Sauté chopped tomatoes in oil until soft',
          'Add curry powder and cook for 1 minute',
          'Add chickpeas and coconut milk, simmer for 10 minutes',
          'Stir in spinach until wilted',
          'Serve over rice'
        ],
        servings: 4,
        prepTime: 10,
        cookTime: 20,
        costEstimate: 2.50,
        tags: ['vegan', 'quick', 'budget'],
        reCookCount: 8,
        image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400',
        createdAt: new Date(Date.now() - 3600000),
      },
      stats: {
        costPerServing: 2.50,
        wasteSaved: 350,
        expiringItemsUsed: 3,
        macros: { calories: 420, protein: 18, carbs: 55, fat: 12 },
      },
      badges: ['NO-WASTE', 'UNDER-$3', 'VEGAN'],
      likes: 234,
      comments: 12,
      reCooks: 8,
      rating: 5,
      createdAt: new Date(Date.now() - 3600000),
      reactions: { youCooked: 15, youreCooked: 2 },
      ingredients: ['1 can chickpeas', '2 cups spinach', '2 medium tomatoes', '2 tbsp curry powder', '1 can coconut milk'],
      recipeSteps: ['Sauté chopped tomatoes in oil until soft', 'Add curry powder and cook for 1 minute', 'Add chickpeas and coconut milk, simmer for 10 minutes', 'Stir in spinach until wilted', 'Serve over rice'],
    },
    {
      id: 'mock-2',
      userId: '2',
      user: users[1],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=400'],
      caption: 'Ramen upgrade on a student budget! Added an egg and some frozen veggies. Total cost: $1.20 💰',
      stats: {
        costPerServing: 1.20,
        wasteSaved: 0,
        expiringItemsUsed: 0,
        macros: { calories: 380, protein: 14, carbs: 52, fat: 10 },
      },
      badges: ['UNDER-$3', 'QUICK'],
      likes: 189,
      comments: 8,
      reCooks: 23,
      rating: 4,
      createdAt: new Date(Date.now() - 7200000),
      reactions: { youCooked: 23, youreCooked: 1 },
    },
    
    // Healthy Kitchen posts
    {
      id: 'mock-3',
      userId: '3',
      user: users[2],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400'],
      caption: 'Buddha bowl perfection 🥗 Roasted sweet potatoes, quinoa, chickpeas, and tahini dressing. Plant-powered goodness!',
      stats: {
        costPerServing: 2.80,
        wasteSaved: 0,
        expiringItemsUsed: 0,
        macros: { calories: 480, protein: 16, carbs: 68, fat: 14 },
      },
      badges: ['VEGAN', 'HIGH-PROTEIN'],
      likes: 678,
      comments: 45,
      reCooks: 56,
      rating: 5,
      createdAt: new Date(Date.now() - 10800000),
      reactions: { youCooked: 56, youreCooked: 1 },
    },
    {
      id: 'mock-4',
      userId: '3',
      user: users[2],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=400'],
      caption: 'Green smoothie bowl topped with fresh berries and granola 🌿 Perfect breakfast to start the day right!',
      stats: {
        costPerServing: 3.20,
        wasteSaved: 0,
        expiringItemsUsed: 0,
        macros: { calories: 320, protein: 12, carbs: 48, fat: 8 },
      },
      badges: ['VEGAN', 'BREAKFAST'],
      likes: 445,
      comments: 22,
      reCooks: 31,
      rating: 5,
      createdAt: new Date(Date.now() - 14400000),
      reactions: { youCooked: 31, youreCooked: 0 },
    },

    // Quick Meals posts
    {
      id: 'mock-5',
      userId: '4',
      user: users[3],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=400'],
      caption: 'Stir-fry rescue! Threw random veggies together with soy sauce and ginger. Ready in 15 minutes! ⏰',
      stats: {
        costPerServing: 1.85,
        wasteSaved: 420,
        expiringItemsUsed: 5,
        macros: { calories: 350, protein: 14, carbs: 45, fat: 12 },
      },
      badges: ['NO-WASTE', 'UNDER-$3', 'QUICK'],
      likes: 512,
      comments: 31,
      reCooks: 42,
      rating: 4,
      createdAt: new Date(Date.now() - 18000000),
      reactions: { youCooked: 42, youreCooked: 5 },
    },
    {
      id: 'mock-6',
      userId: '4',
      user: users[3],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1563379926898-05f4575a45d8?w=400'],
      caption: 'Sheet pan dinner magic! Chicken, potatoes, and broccoli all done in 25 minutes 🍗',
      stats: {
        costPerServing: 3.40,
        wasteSaved: 0,
        expiringItemsUsed: 0,
        macros: { calories: 520, protein: 38, carbs: 42, fat: 18 },
      },
      badges: ['QUICK', 'HIGH-PROTEIN'],
      likes: 389,
      comments: 19,
      reCooks: 28,
      rating: 5,
      createdAt: new Date(Date.now() - 25200000),
      reactions: { youCooked: 28, youreCooked: 2 },
    },

    // Bakery Boss posts
    {
      id: 'mock-7',
      userId: '5',
      user: users[4],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400'],
      caption: 'Fresh sourdough loaf! Been working on my starter for weeks and finally nailed it 🥖✨',
      stats: {
        costPerServing: 0.85,
        wasteSaved: 0,
        expiringItemsUsed: 0,
        macros: { calories: 240, protein: 8, carbs: 48, fat: 2 },
      },
      badges: ['HOMEMADE', 'ARTISAN'],
      likes: 892,
      comments: 56,
      reCooks: 67,
      rating: 5,
      createdAt: new Date(Date.now() - 32400000),
      reactions: { youCooked: 67, youreCooked: 3 },
    },
    {
      id: 'mock-8',
      userId: '5',
      user: users[4],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=400'],
      caption: 'Cinnamon rolls for Sunday brunch! The house smells incredible 😍',
      stats: {
        costPerServing: 1.20,
        wasteSaved: 0,
        expiringItemsUsed: 0,
        macros: { calories: 380, protein: 6, carbs: 58, fat: 14 },
      },
      badges: ['DESSERT', 'BREAKFAST'],
      likes: 734,
      comments: 41,
      reCooks: 89,
      rating: 5,
      createdAt: new Date(Date.now() - 36000000),
      reactions: { youCooked: 89, youreCooked: 1 },
    },

    // Spicy Life posts
    {
      id: 'mock-9',
      userId: '6',
      user: users[5],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=400'],
      caption: 'Homemade hot sauce batch! Mixed habanero, jalapeño, and ghost pepper 🌶️🔥 Not for the faint of heart!',
      stats: {
        costPerServing: 2.10,
        wasteSaved: 0,
        expiringItemsUsed: 0,
        macros: { calories: 15, protein: 0, carbs: 3, fat: 0 },
      },
      badges: ['SPICY', 'CONDIMENT'],
      likes: 456,
      comments: 34,
      reCooks: 12,
      rating: 5,
      createdAt: new Date(Date.now() - 43200000),
      reactions: { youCooked: 12, youreCooked: 8 },
    },
    {
      id: 'mock-10',
      userId: '6',
      user: users[5],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1625937286074-9ca519d5d9df?w=400'],
      caption: 'Thai red curry with extra chilies! Sweat level: maximum 💦🌶️',
      stats: {
        costPerServing: 3.15,
        wasteSaved: 0,
        expiringItemsUsed: 0,
        macros: { calories: 450, protein: 22, carbs: 38, fat: 24 },
      },
      badges: ['SPICY', 'THAI'],
      likes: 567,
      comments: 28,
      reCooks: 34,
      rating: 5,
      createdAt: new Date(Date.now() - 50400000),
      reactions: { youCooked: 34, youreCooked: 6 },
    },

    // Meal Prep Pro posts
    {
      id: 'mock-11',
      userId: '7',
      user: users[6],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1546069901-eacef0df6022?w=400'],
      caption: 'Sunday meal prep complete! 12 meals ready for the week 📦 Chicken bowls, pasta, and overnight oats!',
      stats: {
        costPerServing: 2.50,
        wasteSaved: 0,
        expiringItemsUsed: 0,
        macros: { calories: 480, protein: 32, carbs: 52, fat: 14 },
      },
      badges: ['MEAL-PREP', 'HIGH-PROTEIN'],
      likes: 823,
      comments: 67,
      reCooks: 92,
      rating: 5,
      createdAt: new Date(Date.now() - 57600000),
      reactions: { youCooked: 92, youreCooked: 2 },
    },
    {
      id: 'mock-12',
      userId: '7',
      user: users[6],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1607532941433-304659e8198a?w=400'],
      caption: 'Overnight oats x6! Different flavors for each day. Breakfast sorted 🥣',
      stats: {
        costPerServing: 1.80,
        wasteSaved: 0,
        expiringItemsUsed: 0,
        macros: { calories: 320, protein: 12, carbs: 54, fat: 8 },
      },
      badges: ['MEAL-PREP', 'BREAKFAST'],
      likes: 612,
      comments: 38,
      reCooks: 78,
      rating: 5,
      createdAt: new Date(Date.now() - 64800000),
      reactions: { youCooked: 78, youreCooked: 1 },
    },

    // More Budget Chef posts
    {
      id: 'mock-13',
      userId: '2',
      user: users[1],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400'],
      caption: 'Homemade pizza night! Used leftover veggies from the fridge. Cost only $1.50 per serving! 🍕',
      recipeId: 'recipe-mock-2',
      recipe: {
        id: 'recipe-mock-2',
        userId: '2',
        title: 'Budget Veggie Pizza',
        description: 'Homemade pizza using pantry staples and leftover vegetables',
        ingredients: [
          { id: '1', name: 'Flour', amount: 2, unit: 'cups' },
          { id: '2', name: 'Yeast', amount: 1, unit: 'tsp' },
          { id: '3', name: 'Tomato sauce', amount: 0.5, unit: 'cup' },
          { id: '4', name: 'Mozzarella', amount: 1, unit: 'cup' },
          { id: '5', name: 'Mixed vegetables', amount: 1, unit: 'cup' },
        ],
        steps: [
          'Mix flour, yeast, and warm water. Let rise for 30 minutes',
          'Roll out dough and place on baking sheet',
          'Spread tomato sauce, add cheese and vegetables',
          'Bake at 450°F for 12-15 minutes',
        ],
        servings: 4,
        prepTime: 40,
        cookTime: 15,
        costEstimate: 1.50,
        tags: ['budget', 'homemade'],
        reCookCount: 34,
        image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400',
        createdAt: new Date(Date.now() - 72000000),
      },
      stats: {
        costPerServing: 1.50,
        wasteSaved: 200,
        expiringItemsUsed: 2,
        macros: { calories: 520, protein: 22, carbs: 65, fat: 18 },
      },
      badges: ['UNDER-$3', 'NO-WASTE'],
      likes: 445,
      comments: 28,
      reCooks: 34,
      rating: 4,
      createdAt: new Date(Date.now() - 72000000),
      reactions: { youCooked: 34, youreCooked: 3 },
      ingredients: ['2 cups flour', '1 tsp yeast', '0.5 cup tomato sauce', '1 cup mozzarella', '1 cup mixed vegetables'],
      recipeSteps: ['Mix flour, yeast, and warm water. Let rise for 30 minutes', 'Roll out dough and place on baking sheet', 'Spread tomato sauce, add cheese and vegetables', 'Bake at 450°F for 12-15 minutes'],
    },

    // More Healthy Kitchen posts
    {
      id: 'mock-14',
      userId: '3',
      user: users[2],
      type: 'meal',
      media: ['https://images.unsplash.com/photo-1511690656952-34342bb7c2f2?w=400'],
      caption: 'Avocado toast with everything bagel seasoning and microgreens 🥑 Simple but satisfying!',
      stats: {
        costPerServing: 2.40,
        wasteSaved: 0,
        expiringItemsUsed: 0,
        macros: { calories: 340, protein: 10, carbs: 38, fat: 18 },
      },
      badges: ['VEGAN', 'QUICK'],
      likes: 523,
      comments: 19,
      reCooks: 41,
      rating: 4,
      createdAt: new Date(Date.now() - 79200000),
      reactions: { youCooked: 41, youreCooked: 2 },
    },
  ];
};

// Helper to serialize/deserialize dates in posts
const serializePosts = (posts: Post[]): string => {
  return JSON.stringify(posts, (key, value) => {
    if (key === 'createdAt' && value instanceof Date) {
      return value.toISOString();
    }
    return value;
  });
};

// Helper to clean blob URLs from posts (they become invalid after refresh)
const cleanBlobUrls = (posts: any[]): Post[] => {
  return posts.map((post: any) => {
    // If media contains blob URLs, remove them (they're invalid)
    const cleanedMedia = post.media?.filter((url: string) => {
      // Keep data URLs and regular URLs, remove blob URLs
      if (typeof url === 'string' && url.startsWith('blob:')) {
        return false; // Remove blob URLs
      }
      return true; // Keep data URLs and regular URLs
    }) || [];
    
    return {
      ...post,
      media: cleanedMedia, // Remove blob URLs
      createdAt: new Date(post.createdAt),
    };
  });
};

const deserializePosts = (json: string): Post[] => {
  const parsed = JSON.parse(json);
  return cleanBlobUrls(parsed);
};

// Load initial posts from localStorage or use mock data
const getInitialPosts = (): Post[] => {
  try {
    const stored = localStorage.getItem('cookd_posts');
    if (stored) {
      const parsed = deserializePosts(stored);
      
      // One-time migration: Clean blob URLs from existing posts and save back
      const hasBlobUrls = parsed.some((p: Post) => 
        p.media?.some((url: string) => typeof url === 'string' && url.startsWith('blob:'))
      );
      
      if (hasBlobUrls) {
        const cleaned = cleanBlobUrls(parsed);
        // Save cleaned posts back to localStorage
        try {
          localStorage.setItem('cookd_posts', serializePosts(cleaned));
        } catch (error) {
          console.error('Error saving cleaned posts to localStorage:', error);
        }
        // Merge with mock posts
        const mockPosts = generateMockPosts();
        const existingIds = new Set(cleaned.map((p: Post) => p.id));
        const newMockPosts = mockPosts.filter((p: Post) => !existingIds.has(p.id));
        return [...cleaned, ...newMockPosts];
      }
      
      // Merge with mock posts if localStorage is empty or has fewer posts
      const mockPosts = generateMockPosts();
      const existingIds = new Set(parsed.map((p: Post) => p.id));
      const newMockPosts = mockPosts.filter((p: Post) => !existingIds.has(p.id));
      return [...parsed, ...newMockPosts];
    }
  } catch (error) {
    console.error('Error loading posts from localStorage:', error);
  }
  return generateMockPosts();
};

// Load initial meal plan from localStorage
const getInitialMealPlan = (): MealPlanEntry[] => {
  try {
    const stored = localStorage.getItem('cookd_meal_plan');
    if (stored) {
      const parsed = JSON.parse(stored);
      return parsed.map((e: any) => ({
        ...e,
        date: new Date(e.date),
        cookedAt: e.cookedAt ? new Date(e.cookedAt) : undefined,
      }));
    }
  } catch (error) {
    console.error('Error loading meal plan from localStorage:', error);
  }
  return [];
};

// Load initial grocery list from localStorage
const getInitialGroceryList = (): GroceryItem[] => {
  try {
    const stored = localStorage.getItem('cookd_grocery_list');
    const hasLoggedIn = localStorage.getItem('cookd_has_logged_in');
    
    // If this is a new account (no previous login), clear grocery list
    if (!hasLoggedIn) {
      localStorage.removeItem('cookd_grocery_list');
      return [];
    }
    
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.error('Error loading grocery list from localStorage:', error);
  }
  return [];
};

// Load initial comments from localStorage
const getInitialComments = (): Comment[] => {
  try {
    const stored = localStorage.getItem('cookd_comments');
    if (stored) {
      const parsed = JSON.parse(stored);
      return parsed.map((c: any) => ({
        ...c,
        createdAt: new Date(c.createdAt),
      }));
    }
  } catch (error) {
    console.error('Error loading comments from localStorage:', error);
  }
  return [];
};

// Load initial inventory from localStorage
const getInitialInventory = (): InventoryItem[] => {
  try {
    const stored = localStorage.getItem('cookd_inventory');
    if (stored) {
      const parsed = JSON.parse(stored);
      return parsed.map((item: any) => ({
        ...item,
        expiryDate: item.expiryDate ? new Date(item.expiryDate) : undefined,
        purchaseDate: item.purchaseDate ? new Date(item.purchaseDate) : undefined,
      }));
    }
  } catch (error) {
    console.error('Error loading inventory from localStorage:', error);
  }
  
  // Return sample pantry items for demo
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const nextWeek = new Date();
  nextWeek.setDate(nextWeek.getDate() + 7);
  const nextMonth = new Date();
  nextMonth.setMonth(nextMonth.getMonth() + 1);
  
  return [
    {
      id: 'inv-1',
      name: 'Tomatoes',
      category: 'fridge',
      quantity: 5,
      unit: 'unit',
      expiryDate: nextWeek,
      location: 'fridge',
    },
    {
      id: 'inv-2',
      name: 'Milk',
      category: 'fridge',
      quantity: 1,
      unit: 'L',
      expiryDate: nextWeek,
      location: 'fridge',
    },
    {
      id: 'inv-3',
      name: 'Chicken Breast',
      category: 'freezer',
      quantity: 500,
      unit: 'g',
      location: 'freezer',
    },
    {
      id: 'inv-4',
      name: 'Rice',
      category: 'pantry',
      quantity: 2,
      unit: 'kg',
      location: 'pantry',
    },
    {
      id: 'inv-5',
      name: 'Pasta',
      category: 'pantry',
      quantity: 500,
      unit: 'g',
      location: 'pantry',
    },
    {
      id: 'inv-6',
      name: 'Olive Oil',
      category: 'pantry',
      quantity: 750,
      unit: 'ml',
      location: 'pantry',
    },
    {
      id: 'inv-7',
      name: 'Onions',
      category: 'pantry',
      quantity: 3,
      unit: 'unit',
      location: 'pantry',
    },
    {
      id: 'inv-8',
      name: 'Garlic',
      category: 'pantry',
      quantity: 1,
      unit: 'bulb',
      location: 'pantry',
    },
    {
      id: 'inv-9',
      name: 'Eggs',
      category: 'fridge',
      quantity: 12,
      unit: 'unit',
      expiryDate: nextMonth,
      location: 'fridge',
    },
    {
      id: 'inv-10',
      name: 'Cheese',
      category: 'fridge',
      quantity: 200,
      unit: 'g',
      expiryDate: nextWeek,
      location: 'fridge',
    },
  ];
};

const getInitialSavedPosts = (): string[] => {
  try {
    const stored = localStorage.getItem('cookd_saved_posts');
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

const getInitialFollowingUsers = (): string[] => {
  try {
    const stored = localStorage.getItem('cookd_following_users');
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

// Generate initial AI recipes
const getInitialRecipes = (): Recipe[] => {
  try {
    const stored = localStorage.getItem('cookd_recipes');
    if (stored) {
      const parsed = JSON.parse(stored);
      return parsed.map((recipe: any) => ({
        ...recipe,
        createdAt: new Date(recipe.createdAt),
      }));
    }
  } catch (error) {
    console.error('Error loading recipes from localStorage:', error);
  }

  // Generate a sample AI recipe for demo
  return [
    {
      id: 'ai-recipe-1',
      userId: undefined,
      title: 'Creamy Garlic Pasta',
      description: 'A quick and delicious pasta dish with a creamy garlic sauce, perfect for weeknight dinners.',
      ingredients: [
        { id: '1', name: 'pasta', amount: 8, unit: 'oz', notes: 'any shape' },
        { id: '2', name: 'heavy cream', amount: 1, unit: 'cup' },
        { id: '3', name: 'garlic', amount: 4, unit: 'cloves', notes: 'minced' },
        { id: '4', name: 'parmesan cheese', amount: 0.5, unit: 'cup', notes: 'grated' },
        { id: '5', name: 'olive oil', amount: 2, unit: 'tbsp' },
        { id: '6', name: 'salt and pepper', amount: 1, unit: 'to taste' },
      ],
      steps: [
        'Cook pasta according to package directions',
        'In a pan, heat olive oil and sauté minced garlic until fragrant',
        'Add heavy cream and bring to a gentle simmer',
        'Stir in parmesan cheese until melted and smooth',
        'Toss cooked pasta in the sauce',
        'Season with salt and pepper to taste',
      ],
      servings: 2,
      prepTime: 5,
      cookTime: 15,
      costEstimate: 3.50,
      tags: ['pasta', 'quick', 'italian', 'creamy'],
      reCookCount: 0,
      image: 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400',
      createdAt: new Date(Date.now() - 86400000 * 3),
    },
    {
      id: 'ai-recipe-2',
      userId: undefined,
      title: 'Veggie Stir-Fry Bowl',
      description: 'Colorful and healthy vegetable stir-fry with a savory sauce over rice.',
      ingredients: [
        { id: '1', name: 'rice', amount: 1, unit: 'cup' },
        { id: '2', name: 'mixed vegetables', amount: 3, unit: 'cups', notes: 'bell peppers, broccoli, carrots' },
        { id: '3', name: 'soy sauce', amount: 3, unit: 'tbsp' },
        { id: '4', name: 'ginger', amount: 1, unit: 'tbsp', notes: 'grated' },
        { id: '5', name: 'sesame oil', amount: 1, unit: 'tbsp' },
        { id: '6', name: 'garlic', amount: 2, unit: 'cloves', notes: 'minced' },
      ],
      steps: [
        'Cook rice according to package directions',
        'Heat sesame oil in a wok or large pan',
        'Add garlic and ginger, stir-fry for 30 seconds',
        'Add vegetables and stir-fry for 5-7 minutes',
        'Add soy sauce and toss to coat',
        'Serve over rice',
      ],
      servings: 2,
      prepTime: 10,
      cookTime: 15,
      costEstimate: 4.00,
      tags: ['asian', 'healthy', 'vegetarian', 'quick'],
      reCookCount: 0,
      image: 'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=400',
      createdAt: new Date(Date.now() - 86400000 * 2),
    },
  ];
};

// Get initial saved recipe IDs
const getInitialSavedRecipesWithDefaults = (): string[] => {
  const defaultRecipes = ['ai-recipe-1', 'ai-recipe-2', 'ai-recipe-3'];
  
  try {
    const stored = localStorage.getItem('cookd_saved_recipes');
    const hasLoggedIn = localStorage.getItem('cookd_has_logged_in');
    
    // If this is a new account (no previous login), only keep top 3 default recipes
    if (!hasLoggedIn) {
      localStorage.setItem('cookd_saved_recipes', JSON.stringify(defaultRecipes));
      return defaultRecipes;
    }
    
    if (stored) {
      const savedRecipes = JSON.parse(stored);
      // Ensure the top 3 default recipes are always included
      const allRecipes = [...new Set([...defaultRecipes, ...savedRecipes])];
      return allRecipes;
    }
  } catch {
    // Ignore
  }
  
  // Auto-save the demo AI recipes
  return defaultRecipes;
};

// Generate initial DM conversations
const getInitialConversations = (): DMConversation[] => {
  try {
    const stored = localStorage.getItem('cookd_conversations');
    if (stored) {
      const parsed = JSON.parse(stored);
      return parsed.map((conv: any) => ({
        ...conv,
        createdAt: new Date(conv.createdAt),
        updatedAt: new Date(conv.updatedAt),
        lastMessage: conv.lastMessage ? {
          ...conv.lastMessage,
          createdAt: new Date(conv.lastMessage.createdAt),
        } : undefined,
      }));
    }
  } catch (error) {
    console.error('Error loading conversations:', error);
  }

  // Generate sample conversations
  return [
    {
      id: 'conv-1',
      participants: ['1', '2'],
      participantDetails: [
        {
          id: '2',
          username: 'budgetchef',
          displayName: 'Sarah M.',
          avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
        },
      ],
      lastMessage: {
        id: 'msg-1',
        conversationId: 'conv-1',
        senderId: '2',
        content: "Thanks for the recipe! It turned out amazing!",
        createdAt: new Date(Date.now() - 3600000),
        isRead: false,
      },
      postId: '1',
      postPreview: {
        caption: 'Made this amazing chickpea curry',
        image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400',
      },
      createdAt: new Date(Date.now() - 86400000),
      updatedAt: new Date(Date.now() - 3600000),
    },
    {
      id: 'conv-2',
      participants: ['1', '3'],
      participantDetails: [
        {
          id: '3',
          username: 'foodlover',
          displayName: 'Mike Chen',
          avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
        },
      ],
      lastMessage: {
        id: 'msg-2',
        conversationId: 'conv-2',
        senderId: '1',
        content: "Sure! I'll send you the full recipe.",
        createdAt: new Date(Date.now() - 7200000),
        isRead: true,
      },
      createdAt: new Date(Date.now() - 172800000),
      updatedAt: new Date(Date.now() - 7200000),
    },
  ];
};

// Generate initial messages
const getInitialMessages = (): DMMessage[] => {
  try {
    const stored = localStorage.getItem('cookd_messages');
    if (stored) {
      const parsed = JSON.parse(stored);
      return parsed.map((msg: any) => ({
        ...msg,
        createdAt: new Date(msg.createdAt),
      }));
    }
  } catch (error) {
    console.error('Error loading messages:', error);
  }

  // Generate sample messages
  return [
    {
      id: 'msg-conv1-1',
      conversationId: 'conv-1',
      senderId: '2',
      content: "Hey! Your chickpea curry looks amazing! Could you share the recipe?",
      createdAt: new Date(Date.now() - 86400000),
      isRead: true,
    },
    {
      id: 'msg-conv1-2',
      conversationId: 'conv-1',
      senderId: '1',
      content: "Of course! Here's what you need:\n\n2 cans chickpeas\n1 can coconut milk\n2 tomatoes\nSpinach\nCurry powder, cumin, garlic\n\nSauté the spices, add tomatoes, then chickpeas and coconut milk. Simmer for 15 min, add spinach at the end!",
      createdAt: new Date(Date.now() - 82800000),
      isRead: true,
    },
    {
      id: 'msg-1',
      conversationId: 'conv-1',
      senderId: '2',
      content: "Thanks for the recipe! It turned out amazing!",
      createdAt: new Date(Date.now() - 3600000),
      isRead: false,
    },
    {
      id: 'msg-conv2-1',
      conversationId: 'conv-2',
      senderId: '3',
      content: "Hi! I saw your post about the pasta dish. Would love the recipe!",
      createdAt: new Date(Date.now() - 172800000),
      isRead: true,
    },
    {
      id: 'msg-2',
      conversationId: 'conv-2',
      senderId: '1',
      content: "Sure! I'll send you the full recipe.",
      createdAt: new Date(Date.now() - 7200000),
      isRead: true,
    },
  ];
};

export const useAppStore = create<AppState>((set, get) => ({
  currentUser: generateMockUser(),
  posts: getInitialPosts(),
  comments: getInitialComments(),
  recipes: getInitialRecipes(),
  inventory: getInitialInventory(),
  mealPlan: getInitialMealPlan(),
  groceryList: getInitialGroceryList(),
  savedPosts: getInitialSavedPosts(),
  savedRecipes: getInitialSavedRecipesWithDefaults(),
  followingUsers: getInitialFollowingUsers(),
  conversations: getInitialConversations(),
  messages: getInitialMessages(),
  dietaryRestrictions: (() => {
    try {
      const stored = localStorage.getItem('cookd_dietary_restrictions');
      return stored ? JSON.parse(stored) : { diets: [], allergies: [], restrictions: [], customKeywords: [] };
    } catch {
      return { diets: [], allergies: [], restrictions: [], customKeywords: [] };
    }
  })(),
  
  setCurrentUser: (user) => set({ currentUser: user }),
  
  followUser: (userId) => {
    set((state) => {
      if (state.followingUsers.includes(userId)) return state;
      const newFollowing = [...state.followingUsers, userId];
      try {
        localStorage.setItem('cookd_following_users', JSON.stringify(newFollowing));
      } catch (error) {
        console.error('Error saving following users to localStorage:', error);
      }
      return { followingUsers: newFollowing };
    });
  },
  
  unfollowUser: (userId) => {
    set((state) => {
      const newFollowing = state.followingUsers.filter((id) => id !== userId);
      try {
        localStorage.setItem('cookd_following_users', JSON.stringify(newFollowing));
      } catch (error) {
        console.error('Error saving following users to localStorage:', error);
      }
      return { followingUsers: newFollowing };
    });
  },
  
  addPost: (post) => {
    set((state) => {
      // Clean blob URLs from the new post before saving
      const cleanedPost = {
        ...post,
        media: post.media.filter((url: string) => !url.startsWith('blob:')),
      };
      const newPosts = [cleanedPost, ...state.posts];
      // Save to localStorage
      try {
        localStorage.setItem('cookd_posts', serializePosts(newPosts));
      } catch (error) {
        console.error('Error saving posts to localStorage:', error);
      }
      return { posts: newPosts };
    });
  },
  
  likePost: (postId) => set((state) => {
    const updatedPosts = state.posts.map((p) =>
      p.id === postId
        ? { ...p, likes: p.likes + (p.isLiked ? -1 : 1), isLiked: !p.isLiked }
        : p
    );
    // Save to localStorage
    try {
      localStorage.setItem('cookd_posts', serializePosts(updatedPosts));
    } catch (error) {
      console.error('Error saving posts to localStorage:', error);
    }
    return { posts: updatedPosts };
  }),
  
  addComment: (comment) => {
    set((state) => {
      const newComments = [...state.comments, comment];
      // Update post comment count
      const updatedPosts = state.posts.map((p) =>
        p.id === comment.postId
          ? { ...p, comments: p.comments + 1 }
          : p
      );
      // Save to localStorage
      try {
        localStorage.setItem('cookd_comments', JSON.stringify(newComments.map(c => ({
          ...c,
          createdAt: c.createdAt.toISOString(),
        }))));
        localStorage.setItem('cookd_posts', serializePosts(updatedPosts));
      } catch (error) {
        console.error('Error saving comments to localStorage:', error);
      }
      return { comments: newComments, posts: updatedPosts };
    });
  },
  
  reCookPost: (postId) => {
    set((state) => {
      const updatedPosts = state.posts.map((p) =>
        p.id === postId
          ? { ...p, reCooks: p.reCooks + 1 }
          : p
      );
      // Save to localStorage
      try {
        localStorage.setItem('cookd_posts', serializePosts(updatedPosts));
      } catch (error) {
        console.error('Error saving posts to localStorage:', error);
      }
      return { posts: updatedPosts };
    });
  },
  
  addInventoryItem: (item) => {
    set((state) => {
      const updatedInventory = [...state.inventory];
      
      // Check if item already exists (case-insensitive)
      const existingIndex = updatedInventory.findIndex(
        (invItem) => invItem.name.toLowerCase().trim() === item.name.toLowerCase().trim()
      );
      
      if (existingIndex !== -1) {
        // Item exists, add to quantity (keep the existing item's name casing)
        updatedInventory[existingIndex] = {
          ...updatedInventory[existingIndex],
          quantity: updatedInventory[existingIndex].quantity + item.quantity,
        };
      } else {
        // Item doesn't exist, add new item
        updatedInventory.push(item);
      }
      
      // Save to localStorage
      try {
        localStorage.setItem('cookd_inventory', JSON.stringify(updatedInventory.map(i => ({
          ...i,
          expiryDate: i.expiryDate?.toISOString(),
          purchaseDate: i.purchaseDate?.toISOString(),
        }))));
      } catch (error) {
        console.error('Error saving inventory to localStorage:', error);
      }
      return { inventory: updatedInventory };
    });
  },
  
  updateInventoryItem: (id, updates) => {
    set((state) => {
      const updatedInventory = state.inventory.map((item) =>
        item.id === id ? { ...item, ...updates } : item
      );
      // Save to localStorage
      try {
        localStorage.setItem('cookd_inventory', JSON.stringify(updatedInventory.map(i => ({
          ...i,
          expiryDate: i.expiryDate?.toISOString(),
          purchaseDate: i.purchaseDate?.toISOString(),
        }))));
      } catch (error) {
        console.error('Error saving inventory to localStorage:', error);
      }
      return { inventory: updatedInventory };
    });
  },
  
  deleteInventoryItem: (id) => {
    set((state) => {
      const updatedInventory = state.inventory.filter((item) => item.id !== id);
      // Save to localStorage
      try {
        localStorage.setItem('cookd_inventory', JSON.stringify(updatedInventory.map(i => ({
          ...i,
          expiryDate: i.expiryDate?.toISOString(),
          purchaseDate: i.purchaseDate?.toISOString(),
        }))));
      } catch (error) {
        console.error('Error saving inventory to localStorage:', error);
      }
      return { inventory: updatedInventory };
    });
  },

  deductIngredientsFromInventory: (ingredients) => {
    set((state) => {
      const updatedInventory = [...state.inventory];
      
      // Helper function to parse ingredient text
      const parseIngredient = (ingredientText: string) => {
        // Extract quantity and unit from text like "2 tomatoes", "200g milk", "1 cup flour"
        const quantityMatch = ingredientText.match(/^(\d+\.?\d*)\s*([a-zA-Z]+)?\s+(.+)/);
        if (quantityMatch) {
          const [, qty, possibleUnit, itemName] = quantityMatch;
          const quantity = parseFloat(qty);
          // Check if the second group is a unit (g, kg, ml, l, cup, tsp, tbsp, etc.) or part of name
          const commonUnits = ['g', 'kg', 'ml', 'l', 'cup', 'cups', 'tsp', 'tbsp', 'oz', 'lb', 'lbs', 'can', 'cans', 'piece', 'pieces'];
          const unit = possibleUnit && commonUnits.includes(possibleUnit.toLowerCase()) 
            ? possibleUnit 
            : (possibleUnit ? `${possibleUnit} ${itemName}`.trim() : itemName);
          const name = possibleUnit && commonUnits.includes(possibleUnit.toLowerCase()) 
            ? itemName 
            : (possibleUnit ? `${possibleUnit} ${itemName}` : itemName);
          
          return { quantity, unit: unit || 'unit', name: name.trim() };
        }
        
        // If no quantity found, assume 1 unit
        return { quantity: 1, unit: 'unit', name: ingredientText.trim() };
      };
      
      ingredients.forEach(({ name, amount, unit }) => {
        // Parse the ingredient name in case it contains quantity info
        const parsed = parseIngredient(name);
        const searchName = parsed.name.toLowerCase().trim();
        const searchAmount = amount || parsed.quantity;
        const searchUnit = unit || parsed.unit;
        
        // Try to find matching inventory item (case-insensitive, fuzzy matching)
        const matchIndex = updatedInventory.findIndex(item => {
          const itemName = item.name.toLowerCase().trim();
          // Exact match or contains match (e.g., "tomato" matches "cherry tomatoes")
          return itemName === searchName || 
                 itemName.includes(searchName) || 
                 searchName.includes(itemName);
        });
        
        if (matchIndex !== -1) {
          const item = updatedInventory[matchIndex];
          
          // Unit conversion map
          const unitConversions: Record<string, Record<string, number>> = {
            // Weight conversions to grams
            'g': { 'g': 1, 'kg': 0.001, 'oz': 28.35, 'lb': 453.592 },
            'kg': { 'g': 1000, 'kg': 1, 'oz': 28350, 'lb': 453592 },
            // Volume conversions to ml
            'ml': { 'ml': 1, 'l': 0.001, 'cup': 236.588, 'tsp': 4.929, 'tbsp': 14.787, 'oz': 29.574 },
            'l': { 'ml': 1000, 'l': 1, 'cup': 4.227, 'tsp': 202.884, 'tbsp': 67.628 },
            'cup': { 'ml': 236.588, 'l': 0.237, 'cup': 1, 'tsp': 48, 'tbsp': 16 },
            'tsp': { 'ml': 4.929, 'l': 0.005, 'cup': 0.021, 'tsp': 1, 'tbsp': 0.333 },
            'tbsp': { 'ml': 14.787, 'l': 0.015, 'cup': 0.063, 'tsp': 3, 'tbsp': 1 },
            // Count conversions
            'unit': { 'unit': 1, 'piece': 1, 'can': 1, 'jar': 1, 'clove': 1, 'whole': 1 },
          };
          
          // Normalize units for comparison
          const normalizeUnit = (u: string) => {
            const lower = u.toLowerCase();
            if (['gram', 'grams', 'g'].includes(lower)) return 'g';
            if (['kilogram', 'kilograms', 'kg'].includes(lower)) return 'kg';
            if (['milliliter', 'milliliters', 'ml'].includes(lower)) return 'ml';
            if (['liter', 'liters', 'l'].includes(lower)) return 'l';
            if (['ounce', 'ounces', 'oz'].includes(lower)) return 'oz';
            if (['pound', 'pounds', 'lb', 'lbs'].includes(lower)) return 'lb';
            if (['cup', 'cups'].includes(lower)) return 'cup';
            if (['teaspoon', 'teaspoons', 'tsp'].includes(lower)) return 'tsp';
            if (['tablespoon', 'tablespoons', 'tbsp'].includes(lower)) return 'tbsp';
            if (['piece', 'pieces', 'unit', 'units', 'can', 'cans', 'jar', 'jars', 'clove', 'cloves', 'whole'].includes(lower)) return 'unit';
            return lower;
          };
          
          const itemUnit = normalizeUnit(item.unit);
          const recipeUnit = normalizeUnit(searchUnit);
          
          let amountToDeduct = searchAmount;
          
          // Try to convert units if they don't match
          if (itemUnit !== recipeUnit) {
            // Check if conversion is possible
            const conversionKey = unitConversions[itemUnit];
            if (conversionKey && conversionKey[recipeUnit]) {
              // Convert recipe amount to inventory unit
              amountToDeduct = searchAmount * conversionKey[recipeUnit];
            } else {
              // Units incompatible, skip deduction
              console.warn(`Cannot convert ${recipeUnit} to ${itemUnit} for ${item.name}`);
              return;
            }
          }
          
          const newQuantity = item.quantity - amountToDeduct;
          
          if (newQuantity <= 0) {
            // Remove item if quantity reaches 0 or below
            updatedInventory.splice(matchIndex, 1);
          } else {
            // Update quantity
            updatedInventory[matchIndex] = {
              ...item,
              quantity: Math.round(newQuantity * 100) / 100, // Round to 2 decimals
            };
          }
        }
      });
      
      // Save to localStorage
      try {
        localStorage.setItem('cookd_inventory', JSON.stringify(updatedInventory.map(i => ({
          ...i,
          expiryDate: i.expiryDate?.toISOString(),
          purchaseDate: i.purchaseDate?.toISOString(),
        }))));
      } catch (error) {
        console.error('Error saving inventory to localStorage:', error);
      }
      
      return { inventory: updatedInventory };
    });
  },

  checkMissingIngredients: (ingredients) => {
    const state = get();
    const missing: { name: string; amount: number; unit: string }[] = [];
    
    // Helper function to parse ingredient text
    const parseIngredient = (ingredientText: string) => {
      const quantityMatch = ingredientText.match(/^(\d+\.?\d*)\s*([a-zA-Z]+)?\s+(.+)/);
      if (quantityMatch) {
        const [, qty, possibleUnit, itemName] = quantityMatch;
        const quantity = parseFloat(qty);
        const commonUnits = ['g', 'kg', 'ml', 'l', 'cup', 'cups', 'tsp', 'tbsp', 'oz', 'lb', 'lbs', 'can', 'cans', 'piece', 'pieces'];
        const unit = possibleUnit && commonUnits.includes(possibleUnit.toLowerCase()) 
          ? possibleUnit 
          : (possibleUnit ? `${possibleUnit} ${itemName}`.trim() : itemName);
        const name = possibleUnit && commonUnits.includes(possibleUnit.toLowerCase()) 
          ? itemName 
          : (possibleUnit ? `${possibleUnit} ${itemName}` : itemName);
        
        return { quantity, unit: unit || 'unit', name: name.trim() };
      }
      return { quantity: 1, unit: 'unit', name: ingredientText.trim() };
    };
    
    // Normalize units
    const normalizeUnit = (u: string) => {
      const lower = u.toLowerCase();
      if (['gram', 'grams', 'g'].includes(lower)) return 'g';
      if (['kilogram', 'kilograms', 'kg'].includes(lower)) return 'kg';
      if (['milliliter', 'milliliters', 'ml'].includes(lower)) return 'ml';
      if (['liter', 'liters', 'l'].includes(lower)) return 'l';
      if (['ounce', 'ounces', 'oz'].includes(lower)) return 'oz';
      if (['pound', 'pounds', 'lb', 'lbs'].includes(lower)) return 'lb';
      if (['cup', 'cups'].includes(lower)) return 'cup';
      if (['teaspoon', 'teaspoons', 'tsp'].includes(lower)) return 'tsp';
      if (['tablespoon', 'tablespoons', 'tbsp'].includes(lower)) return 'tbsp';
      if (['piece', 'pieces', 'unit', 'units', 'can', 'cans', 'jar', 'jars', 'clove', 'cloves', 'whole'].includes(lower)) return 'unit';
      return lower;
    };
    
    ingredients.forEach(({ name, amount, unit }) => {
      const parsed = parseIngredient(name);
      const searchName = parsed.name.toLowerCase().trim();
      const searchAmount = amount || parsed.quantity;
      const searchUnit = normalizeUnit(unit || parsed.unit);
      
      // Try to find matching inventory item
      const inventoryItem = state.inventory.find(item => {
        const itemName = item.name.toLowerCase().trim();
        return itemName === searchName || 
               itemName.includes(searchName) || 
               searchName.includes(itemName);
      });
      
      if (!inventoryItem) {
        // Item not in inventory at all
        missing.push({ name, amount: searchAmount, unit });
      } else {
        // Check if we have enough quantity
        const itemUnit = normalizeUnit(inventoryItem.unit);
        
        // Unit conversion map (same as deduction function)
        const unitConversions: Record<string, Record<string, number>> = {
          'g': { 'g': 1, 'kg': 0.001, 'oz': 28.35, 'lb': 453.592 },
          'kg': { 'g': 1000, 'kg': 1, 'oz': 28350, 'lb': 453592 },
          'ml': { 'ml': 1, 'l': 0.001, 'cup': 236.588, 'tsp': 4.929, 'tbsp': 14.787, 'oz': 29.574 },
          'l': { 'ml': 1000, 'l': 1, 'cup': 4.227, 'tsp': 202.884, 'tbsp': 67.628 },
          'cup': { 'ml': 236.588, 'l': 0.237, 'cup': 1, 'tsp': 48, 'tbsp': 16 },
          'tsp': { 'ml': 4.929, 'l': 0.005, 'cup': 0.021, 'tsp': 1, 'tbsp': 0.333 },
          'tbsp': { 'ml': 14.787, 'l': 0.015, 'cup': 0.063, 'tsp': 3, 'tbsp': 1 },
          'unit': { 'unit': 1, 'piece': 1, 'can': 1, 'jar': 1, 'clove': 1, 'whole': 1 },
        };
        
        let requiredAmount = searchAmount;
        
        // Try to convert units if they don't match
        if (itemUnit !== searchUnit) {
          const conversionKey = unitConversions[itemUnit];
          if (conversionKey && conversionKey[searchUnit]) {
            requiredAmount = searchAmount * conversionKey[searchUnit];
          }
        }
        
        // Check if we have enough
        if (inventoryItem.quantity < requiredAmount) {
          // Not enough quantity
          const shortfall = requiredAmount - inventoryItem.quantity;
          missing.push({ name, amount: Math.round(shortfall * 100) / 100, unit: inventoryItem.unit });
        }
      }
    });
    
    return { missing, hasAll: missing.length === 0 };
  },
  
  addMealPlanEntry: (entry) => {
    set((state) => {
      const newMealPlan = [...state.mealPlan, entry];
      // Save to localStorage
      try {
        localStorage.setItem('cookd_meal_plan', JSON.stringify(newMealPlan.map(e => ({
          ...e,
          date: e.date.toISOString(),
          cookedAt: e.cookedAt?.toISOString(),
        }))));
      } catch (error) {
        console.error('Error saving meal plan to localStorage:', error);
      }
      return { mealPlan: newMealPlan };
    });
  },
  
  updateMealPlanEntry: (id, updates) => {
    set((state) => {
      const updatedMealPlan = state.mealPlan.map((entry) =>
        entry.id === id ? { ...entry, ...updates } : entry
      );
      // Save to localStorage
      try {
        localStorage.setItem('cookd_meal_plan', JSON.stringify(updatedMealPlan.map(e => ({
          ...e,
          date: e.date.toISOString(),
          cookedAt: e.cookedAt?.toISOString(),
        }))));
      } catch (error) {
        console.error('Error saving meal plan to localStorage:', error);
      }
      return { mealPlan: updatedMealPlan };
    });
  },
  
  addGroceryItem: (item) => {
    set((state) => {
      // Check if item already exists in grocery list (case-insensitive name match)
      const existingIndex = state.groceryList.findIndex(
        (existing) => existing.name.toLowerCase() === item.name.toLowerCase() && !existing.isChecked
      );
      
      let newGroceryList: GroceryItem[];
      if (existingIndex >= 0) {
        // Merge quantities if item already exists
        newGroceryList = state.groceryList.map((existing, index) => {
          if (index === existingIndex) {
            return {
              ...existing,
              quantity: existing.quantity + item.quantity,
            };
          }
          return existing;
        });
      } else {
        // Add new item
        newGroceryList = [...state.groceryList, item];
      }
      
      // Save to localStorage
      try {
        localStorage.setItem('cookd_grocery_list', JSON.stringify(newGroceryList));
      } catch (error) {
        console.error('Error saving grocery list to localStorage:', error);
      }
      return { groceryList: newGroceryList };
    });
  },
  
  toggleGroceryItem: (id) => {
    set((state) => {
      const item = state.groceryList.find((i) => i.id === id);
      if (!item) return state;
      
      const newCheckedState = !item.isChecked;
      const updatedList = state.groceryList.map((i) =>
        i.id === id ? { ...i, isChecked: newCheckedState } : i
      );
      
      // If checking the item (marking as bought), add to inventory
      if (newCheckedState) {
        const updatedInventory = [...state.inventory];
        
        // Check if item already exists in inventory
        const existingIndex = updatedInventory.findIndex(
          (invItem) => invItem.name.toLowerCase().trim() === item.name.toLowerCase().trim()
        );
        
        if (existingIndex !== -1) {
          // Item exists, add to quantity
          updatedInventory[existingIndex] = {
            ...updatedInventory[existingIndex],
            quantity: updatedInventory[existingIndex].quantity + item.quantity,
          };
        } else {
          // Item doesn't exist, add new inventory item
          const newInventoryItem = {
            id: crypto.randomUUID(),
            name: item.name,
            quantity: item.quantity,
            unit: item.unit,
            category: (item.category?.toLowerCase() === 'fridge' || item.category?.toLowerCase() === 'freezer' || item.category?.toLowerCase() === 'pantry' 
              ? item.category.toLowerCase() 
              : 'fridge') as 'fridge' | 'freezer' | 'pantry',
            location: item.category?.toLowerCase() === 'freezer' ? 'freezer' : (item.category?.toLowerCase() === 'pantry' ? 'pantry' : 'fridge'),
            expiryDate: undefined,
            purchaseDate: new Date(),
          };
          updatedInventory.push(newInventoryItem);
        }
        
        // Save inventory to localStorage
        try {
          localStorage.setItem('cookd_inventory', JSON.stringify(updatedInventory.map(i => ({
            ...i,
            expiryDate: i.expiryDate?.toISOString(),
            purchaseDate: i.purchaseDate?.toISOString(),
          }))));
        } catch (error) {
          console.error('Error saving inventory to localStorage:', error);
        }
        
        // Save updated grocery list to localStorage
        try {
          localStorage.setItem('cookd_grocery_list', JSON.stringify(updatedList));
        } catch (error) {
          console.error('Error saving grocery list to localStorage:', error);
        }
        
        return { groceryList: updatedList, inventory: updatedInventory };
      }
      
      // If unchecking, just update the grocery list
      try {
        localStorage.setItem('cookd_grocery_list', JSON.stringify(updatedList));
      } catch (error) {
        console.error('Error saving grocery list to localStorage:', error);
      }
      return { groceryList: updatedList };
    });
  },
  
  deleteGroceryItem: (id) => {
    set((state) => {
      const updatedList = state.groceryList.filter((item) => item.id !== id);
      // Save to localStorage
      try {
        localStorage.setItem('cookd_grocery_list', JSON.stringify(updatedList));
      } catch (error) {
        console.error('Error saving grocery list to localStorage:', error);
      }
      return { groceryList: updatedList };
    });
  },

  clearGroceryList: () => {
    set(() => {
      // Clear all items from grocery list without adding to inventory
      try {
        localStorage.setItem('cookd_grocery_list', JSON.stringify([]));
      } catch (error) {
        console.error('Error clearing grocery list:', error);
      }
      return { groceryList: [] };
    });
  },
  
  savePost: (postId) => {
    set((state) => {
      const newSavedPosts = [...state.savedPosts, postId];
      // Save to localStorage
      try {
        localStorage.setItem('cookd_saved_posts', JSON.stringify(newSavedPosts));
      } catch (error) {
        console.error('Error saving saved posts to localStorage:', error);
      }
      return { savedPosts: newSavedPosts };
    });
  },
  
  unsavePost: (postId) => {
    set((state) => {
      const newSavedPosts = state.savedPosts.filter((id) => id !== postId);
      // Save to localStorage
      try {
        localStorage.setItem('cookd_saved_posts', JSON.stringify(newSavedPosts));
      } catch (error) {
        console.error('Error saving saved posts to localStorage:', error);
      }
      return { savedPosts: newSavedPosts };
    });
  },
  
  saveRecipe: (recipeId) => {
    set((state) => {
      const newSavedRecipes = [...state.savedRecipes, recipeId];
      // Save to localStorage
      try {
        localStorage.setItem('cookd_saved_recipes', JSON.stringify(newSavedRecipes));
      } catch (error) {
        console.error('Error saving saved recipes to localStorage:', error);
      }
      return { savedRecipes: newSavedRecipes };
    });
  },
  
  unsaveRecipe: (recipeId) => {
    set((state) => {
      const newSavedRecipes = state.savedRecipes.filter((id) => id !== recipeId);
      // Save to localStorage
      try {
        localStorage.setItem('cookd_saved_recipes', JSON.stringify(newSavedRecipes));
      } catch (error) {
        console.error('Error saving saved recipes to localStorage:', error);
      }
      return { savedRecipes: newSavedRecipes };
    });
  },

  reactToPost: (postId, reaction) => {
    set((state) => {
      const updatedPosts = state.posts.map((p) => {
        if (p.id === postId) {
          const reactions = p.reactions || { youCooked: 0, youreCooked: 0 };
          const currentReaction = p.userReaction;

          // Remove previous reaction if exists
          if (currentReaction === 'youCooked') reactions.youCooked--;
          if (currentReaction === 'youreCooked') reactions.youreCooked--;

          // Add new reaction
          if (reaction === 'youCooked') reactions.youCooked++;
          if (reaction === 'youreCooked') reactions.youreCooked++;

          return { ...p, reactions, userReaction: reaction };
        }
        return p;
      });

      try {
        localStorage.setItem('cookd_posts', serializePosts(updatedPosts));
      } catch (error) {
        console.error('Error saving posts to localStorage:', error);
      }
      return { posts: updatedPosts };
    });
  },

  removeReaction: (postId) => {
    set((state) => {
      const updatedPosts = state.posts.map((p) => {
        if (p.id === postId) {
          const reactions = p.reactions || { youCooked: 0, youreCooked: 0 };
          const currentReaction = p.userReaction;

          // Remove current reaction
          if (currentReaction === 'youCooked') reactions.youCooked--;
          if (currentReaction === 'youreCooked') reactions.youreCooked--;

          return { ...p, reactions, userReaction: null };
        }
        return p;
      });

      try {
        localStorage.setItem('cookd_posts', serializePosts(updatedPosts));
      } catch (error) {
        console.error('Error saving posts to localStorage:', error);
      }
      return { posts: updatedPosts };
    });
  },

  addRecipe: (recipe) => {
    set((state) => {
      const newRecipes = [...state.recipes, recipe];
      try {
        localStorage.setItem('cookd_recipes', JSON.stringify(newRecipes.map(r => ({
          ...r,
          createdAt: r.createdAt.toISOString(),
        }))));
      } catch (error) {
        console.error('Error saving recipes to localStorage:', error);
      }
      return { recipes: newRecipes };
    });
  },

  getOrCreateConversation: (otherUserId, postId) => {
    const state = get();
    const currentUserId = state.currentUser?.id;
    if (!currentUserId) return '';

    // Check if conversation already exists
    const existing = state.conversations.find(conv =>
      conv.participants.includes(currentUserId) &&
      conv.participants.includes(otherUserId) &&
      (!postId || conv.postId === postId)
    );

    if (existing) return existing.id;

    // Create new conversation
    const otherUser = state.posts.find(p => p.userId === otherUserId)?.user;
    if (!otherUser) return '';

    const post = postId ? state.posts.find(p => p.id === postId) : undefined;

    const newConv: DMConversation = {
      id: crypto.randomUUID(),
      participants: [currentUserId, otherUserId],
      participantDetails: [{
        id: otherUser.id,
        username: otherUser.username,
        displayName: otherUser.displayName,
        avatar: otherUser.avatar,
      }],
      postId,
      postPreview: post ? {
        caption: post.caption,
        image: post.media[0] || '',
      } : undefined,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    set((state) => {
      const newConversations = [...state.conversations, newConv];
      try {
        localStorage.setItem('cookd_conversations', JSON.stringify(newConversations.map(c => ({
          ...c,
          createdAt: c.createdAt.toISOString(),
          updatedAt: c.updatedAt.toISOString(),
          lastMessage: c.lastMessage ? {
            ...c.lastMessage,
            createdAt: c.lastMessage.createdAt.toISOString(),
          } : undefined,
        }))));
      } catch (error) {
        console.error('Error saving conversations:', error);
      }
      return { conversations: newConversations };
    });

    return newConv.id;
  },

  sendMessage: (conversationId, content) => {
    const state = get();
    const currentUserId = state.currentUser?.id;
    if (!currentUserId) return;

    const newMessage: DMMessage = {
      id: crypto.randomUUID(),
      conversationId,
      senderId: currentUserId,
      content,
      createdAt: new Date(),
      isRead: false,
    };

    set((state) => {
      const newMessages = [...state.messages, newMessage];
      const updatedConversations = state.conversations.map(conv =>
        conv.id === conversationId
          ? { ...conv, lastMessage: newMessage, updatedAt: new Date() }
          : conv
      );

      try {
        localStorage.setItem('cookd_messages', JSON.stringify(newMessages.map(m => ({
          ...m,
          createdAt: m.createdAt.toISOString(),
        }))));
        localStorage.setItem('cookd_conversations', JSON.stringify(updatedConversations.map(c => ({
          ...c,
          createdAt: c.createdAt.toISOString(),
          updatedAt: c.updatedAt.toISOString(),
          lastMessage: c.lastMessage ? {
            ...c.lastMessage,
            createdAt: c.lastMessage.createdAt.toISOString(),
          } : undefined,
        }))));
      } catch (error) {
        console.error('Error saving messages:', error);
      }

      return { messages: newMessages, conversations: updatedConversations };
    });
  },

  getConversationMessages: (conversationId) => {
    const state = get();
    return state.messages
      .filter(m => m.conversationId === conversationId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  },

  updateDietaryRestrictions: (restrictions) => {
    set((state) => {
      const updated = {
        diets: restrictions.diets ?? state.dietaryRestrictions.diets,
        allergies: restrictions.allergies ?? state.dietaryRestrictions.allergies,
        restrictions: restrictions.restrictions ?? state.dietaryRestrictions.restrictions,
        customKeywords: restrictions.customKeywords ?? state.dietaryRestrictions.customKeywords,
      };
      try {
        localStorage.setItem('cookd_dietary_restrictions', JSON.stringify(updated));
      } catch (error) {
        console.error('Error saving dietary restrictions:', error);
      }
      return { dietaryRestrictions: updated };
    });
  },

  checkRecipeViolations: (recipe) => {
    const state = get();
    const violations: string[] = [];
    const { diets, allergies, restrictions, customKeywords } = state.dietaryRestrictions;

    // Check ingredients against dietary restrictions
    const recipeText = [
      recipe.title,
      recipe.description,
      ...recipe.ingredients.map(i => i.name),
      ...recipe.steps,
    ].join(' ').toLowerCase();

    // Check diets
    if (diets.includes('vegan')) {
      if (recipeText.match(/\b(meat|chicken|beef|pork|fish|salmon|egg|milk|cheese|butter|cream|honey)\b/)) {
        violations.push('Contains non-vegan ingredients');
      }
    }
    if (diets.includes('vegetarian')) {
      if (recipeText.match(/\b(meat|chicken|beef|pork|fish|salmon)\b/)) {
        violations.push('Contains meat or fish');
      }
    }
    if (diets.includes('keto')) {
      if (recipeText.match(/\b(pasta|rice|bread|potato|sugar|flour|noodles)\b/)) {
        violations.push('Contains high-carb ingredients (not keto-friendly)');
      }
    }
    if (diets.includes('paleo')) {
      if (recipeText.match(/\b(pasta|rice|bread|beans|lentils|dairy|cheese|milk)\b/)) {
        violations.push('Contains grains, legumes, or dairy (not paleo-friendly)');
      }
    }

    // Check allergies
    if (allergies.includes('nuts') && recipeText.match(/\b(nut|almond|walnut|pecan|cashew|peanut|hazelnut)\b/)) {
      violations.push('⚠️ Contains nuts - ALLERGY WARNING');
    }
    if (allergies.includes('dairy') && recipeText.match(/\b(milk|cheese|butter|cream|yogurt|dairy)\b/)) {
      violations.push('⚠️ Contains dairy - ALLERGY WARNING');
    }
    if (allergies.includes('gluten') && recipeText.match(/\b(wheat|flour|bread|pasta|gluten)\b/)) {
      violations.push('⚠️ Contains gluten - ALLERGY WARNING');
    }
    if (allergies.includes('shellfish') && recipeText.match(/\b(shrimp|crab|lobster|shellfish|prawn)\b/)) {
      violations.push('⚠️ Contains shellfish - ALLERGY WARNING');
    }
    if (allergies.includes('soy') && recipeText.match(/\b(soy|tofu|miso|tempeh)\b/)) {
      violations.push('⚠️ Contains soy - ALLERGY WARNING');
    }
    if (allergies.includes('eggs') && recipeText.match(/\b(egg|eggs)\b/)) {
      violations.push('⚠️ Contains eggs - ALLERGY WARNING');
    }

    // Check restrictions
    if (restrictions.includes('no-alcohol') && recipeText.match(/\b(wine|beer|vodka|rum|alcohol|whiskey)\b/)) {
      violations.push('Contains alcohol');
    }
    if (restrictions.includes('halal') && recipeText.match(/\b(pork|bacon|ham|alcohol|wine)\b/)) {
      violations.push('May not be halal (contains pork or alcohol)');
    }
    if (restrictions.includes('kosher') && recipeText.match(/\b(pork|bacon|ham|shellfish)\b/)) {
      violations.push('May not be kosher (contains pork or shellfish)');
    }

    // Check custom keywords
    customKeywords.forEach((keyword) => {
      const keywordLower = keyword.toLowerCase().trim();
      if (keywordLower && recipeText.includes(keywordLower)) {
        violations.push(`Contains "${keyword}" (custom restriction)`);
      }
    });

    return { violates: violations.length > 0, violations };
  },
}));

