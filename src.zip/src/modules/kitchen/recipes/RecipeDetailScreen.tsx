import { ShoppingCart, Repeat2, Sparkles, Clock, Users, Calendar, Share2, Bookmark, AlertCircle, ArrowLeft } from 'lucide-react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { useState, useMemo } from 'react';
import { useAppStore } from '../../../store/appStore';
import { useToast } from '../../../components/ui/ToastContext';
import { formatCurrency } from '../../../lib/utils';
import type { Recipe, GroceryItem } from '../../../types';
import { Screen } from '../../../components/layout/Screen';

export function RecipeDetailScreen() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { showToast } = useToast();
  const posts = useAppStore((state) => state.posts);
  const recipes = useAppStore((state) => state.recipes);
  const addGroceryItem = useAppStore((state) => state.addGroceryItem);
  const savedRecipes = useAppStore((state) => state.savedRecipes);
  const saveRecipe = useAppStore((state) => state.saveRecipe);
  const unsaveRecipe = useAppStore((state) => state.unsaveRecipe);
  const checkMissingIngredients = useAppStore((state) => state.checkMissingIngredients);
  const followUser = useAppStore((state) => state.followUser);
  const unfollowUser = useAppStore((state) => state.unfollowUser);
  const followingUsers = useAppStore((state) => state.followingUsers);
  const currentUser = useAppStore((state) => state.currentUser);
  const checkRecipeViolations = useAppStore((state) => state.checkRecipeViolations);
  const dietaryRestrictions = useAppStore((state) => state.dietaryRestrictions);
  
  // Get recipe from location state if coming from meal plan
  const recipeFromState = location.state?.recipe;

  const post = posts.find((p) => p.recipeId === id);
  const recipeFromStore = recipes.find((r) => r.id === id);

  // Try to get recipe from: state, store, post, or create default
  const baseRecipe: Recipe = recipeFromState || recipeFromStore || post?.recipe || {
    id: id || '1',
    title: 'Chickpea Spinach Curry',
    description: 'A delicious and budget-friendly curry that uses up expiring vegetables',
    ingredients: [
      { id: '1', name: 'Chickpeas', amount: 1, unit: 'can' },
      { id: '2', name: 'Spinach', amount: 200, unit: 'g' },
      { id: '3', name: 'Cherry tomatoes', amount: 150, unit: 'g' },
      { id: '4', name: 'Onion', amount: 1, unit: 'medium' },
      { id: '5', name: 'Garlic', amount: 2, unit: 'cloves' },
      { id: '6', name: 'Curry powder', amount: 2, unit: 'tsp' },
    ],
    steps: [
      'Heat oil in a large pan over medium heat',
      'Add chopped onion and garlic, cook until soft',
      'Add curry powder and stir for 1 minute',
      'Add chickpeas and tomatoes, cook for 5 minutes',
      'Add spinach and cook until wilted',
      'Season with salt and serve hot',
    ],
    servings: 4,
    prepTime: 10,
    cookTime: 15,
    costEstimate: 2.50,
    tags: [],
    reCookCount: 0,
    createdAt: new Date(),
  };

  // Servings adjustment state
  const [adjustedServings, setAdjustedServings] = useState(baseRecipe.servings);
  const [showMissingModal, setShowMissingModal] = useState(false);
  const [showAIPrompt, setShowAIPrompt] = useState(false);

  // Calculate scaled recipe based on adjusted servings
  const recipe = useMemo(() => {
    const multiplier = adjustedServings / baseRecipe.servings;
    return {
      ...baseRecipe,
      servings: adjustedServings,
      ingredients: baseRecipe.ingredients.map(ing => ({
        ...ing,
        amount: Math.round(ing.amount * multiplier * 100) / 100, // Round to 2 decimals
      })),
    };
  }, [baseRecipe, adjustedServings]);

  // Check if we have all ingredients
  const ingredientsCheck = useMemo(() => {
    return checkMissingIngredients(
      recipe.ingredients.map(ing => ({
        name: ing.name,
        amount: ing.amount,
        unit: ing.unit
      }))
    );
  }, [recipe.ingredients, checkMissingIngredients]);

  const isRecipeSaved = savedRecipes.includes(recipe.id);
  const isFollowing = post ? followingUsers.includes(post.userId) : false;

  // Check dietary violations
  const hasRestrictions = dietaryRestrictions.diets.length > 0 || 
                         dietaryRestrictions.allergies.length > 0 || 
                         dietaryRestrictions.restrictions.length > 0;
  const violations = hasRestrictions ? checkRecipeViolations(recipe) : { violates: false, violations: [] };

  const handleFollow = () => {
    if (!post || !currentUser || post.userId === currentUser.id) return;
    
    if (isFollowing) {
      unfollowUser(post.userId);
      showToast('Unfollowed', 'success');
    } else {
      followUser(post.userId);
      showToast('Following! 🎉', 'success');
    }
  };

  const handleCookNow = () => {
    // Check if we have all ingredients
    if (!ingredientsCheck.hasAll) {
      // Show AI prompt instead
      setShowAIPrompt(true);
      return;
    }
    
    // Navigate to capture screen first, then compose with recipe
    navigate('/post/capture', { 
      state: { 
        recipeId: recipe.id,
        draftRecipe: recipe,
        autoFill: true 
      } 
    });
  };

  const handleShare = () => {
    // Share button auto-populates recipe
    navigate('/create', {
      state: {
        recipe,
        recipeId: recipe.id,
        autoFill: true
      }
    });
  };

  const handleAddMissingToGrocery = () => {
    const { missing } = ingredientsCheck;
    missing.forEach((ing) => {
      const groceryItem: GroceryItem = {
        id: crypto.randomUUID(),
        name: ing.name,
        quantity: ing.amount,
        unit: ing.unit,
        category: 'Produce',
        isChecked: false,
        recipeId: recipe.id,
      };
      addGroceryItem(groceryItem);
    });
    
    showToast(`Added ${missing.length} missing ingredients to grocery list! 🛒`, 'success');
    setShowMissingModal(false);
  };

  const handlePlanLater = () => {
    // Navigate to meal plan with recipe pre-selected
    navigate('/kitchen/meal-plan/add', { 
      state: { 
        recipeId: recipe.id,
        recipe: recipe 
      } 
    });
  };

  const handleAddToList = () => {
    const inventory = useAppStore.getState().inventory;
    let addedCount = 0;

    // Add ingredients to grocery list (respecting inventory)
    recipe.ingredients.forEach((ing) => {
      // Check if ingredient is already in inventory (case-insensitive name match)
      const inInventory = inventory.some(
        (invItem) => invItem.name.toLowerCase() === ing.name.toLowerCase()
      );
      
      // Only add to grocery list if not in inventory
      if (!inInventory) {
        // Determine category based on ingredient name
        let category = 'Produce';
        const nameLower = ing.name.toLowerCase();
        if (nameLower.includes('can') || nameLower.includes('jar') || nameLower.includes('bottle')) {
          category = 'Canned';
        } else if (nameLower.includes('frozen') || nameLower.includes('ice')) {
          category = 'Frozen';
        } else if (nameLower.includes('spice') || nameLower.includes('flour') || nameLower.includes('sugar') || nameLower.includes('oil')) {
          category = 'Pantry';
        } else if (nameLower.includes('milk') || nameLower.includes('cheese') || nameLower.includes('yogurt') || nameLower.includes('butter')) {
          category = 'Dairy';
        } else if (nameLower.includes('meat') || nameLower.includes('chicken') || nameLower.includes('beef') || nameLower.includes('fish')) {
          category = 'Meat';
        }
        
        const groceryItem: GroceryItem = {
          id: crypto.randomUUID(),
          name: ing.name,
          quantity: ing.amount,
          unit: ing.unit,
          category,
          isChecked: false,
          recipeId: recipe.id,
        };
        addGroceryItem(groceryItem);
        addedCount++;
      }
    });
    
    if (addedCount > 0) {
      showToast(`Added ${addedCount} ingredients to your grocery list! 🛒`, 'success');
    } else {
      showToast('All ingredients already in your inventory! ✅', 'success');
    }
  };

  const handleRemix = () => {
    navigate(`/recipe/${recipe.id}/transform`);
  };

  const handleSaveRecipe = () => {
    if (!recipe) return;
    
    if (isRecipeSaved) {
      unsaveRecipe(recipe.id);
      showToast('Recipe unsaved', 'success');
    } else {
      saveRecipe(recipe.id);
      showToast('Recipe saved! 💾', 'success');
    }
  };

  return (
    <Screen>
      {/* Header with Back Button */}
      <header className="sticky top-0 z-40 bg-white border-b border-gray-200">
        <div className="flex items-center justify-between px-4 py-3">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 touch-target"
            aria-label="Back"
          >
            <ArrowLeft size={24} className="text-gray-600" />
          </button>
          <h1 className="text-sm font-semibold text-brand-teal">Recipe</h1>
          <button
            onClick={handleSaveRecipe}
            className="p-2 -mr-2 touch-target"
            aria-label={isRecipeSaved ? "Unsave" : "Save"}
          >
            <Bookmark 
              size={24} 
              className={isRecipeSaved ? "fill-brand-teal text-brand-teal" : "text-gray-600"}
            />
          </button>
        </div>
      </header>

      {/* Recipe Image */}
      {(recipe.image || post?.media[0]) && (
        <div className="w-full aspect-video bg-gray-100">
          <img
            src={recipe.image || post?.media[0]}
            alt={recipe.title}
            className="w-full h-full object-cover"
          />
        </div>
      )}

      <div className="px-4 py-6 space-y-6">
        {/* Dietary Violation Warning */}
        {violations.violates && (
          <div className="p-4 bg-red-50 border-2 border-red-200 rounded-xl space-y-2">
            <div className="flex items-start gap-2">
              <AlertCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-red-900 text-sm">Dietary Restriction Alert</p>
                <p className="text-xs text-red-700 mt-1">
                  This recipe may not align with your dietary preferences:
                </p>
                <ul className="mt-2 space-y-1">
                  {violations.violations.map((violation, idx) => (
                    <li key={idx} className="text-xs text-red-700">
                      • {violation}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Recipe Header */}
        <div>
          <h1 className="text-2xl font-bold mb-2">{recipe.title}</h1>
          <p className="text-gray-600">{recipe.description}</p>
        </div>

        {/* Creator Info */}
        {post && (
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
            <img
              src={post.user.avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=default'}
              alt={post.user.displayName}
              className="w-10 h-10 rounded-full object-cover"
            />
            <div className="flex-1">
              <p className="font-semibold text-sm">{post.user.displayName}</p>
              <p className="text-xs text-gray-600">{post.reCooks} people re-cooked this</p>
            </div>
            {post.userId !== currentUser?.id && (
              <button 
                onClick={handleFollow}
                className={`text-sm font-medium touch-target px-4 py-1.5 rounded-full ${
                  isFollowing 
                    ? 'bg-gray-200 text-gray-700' 
                    : 'bg-brand-teal text-white'
                }`}
              >
                {isFollowing ? 'Following' : 'Follow'}
              </button>
            )}
          </div>
        )}

        {/* Quick Info */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <Clock size={20} className="mx-auto mb-1 text-gray-600" />
            <p className="text-xs text-gray-600">Prep</p>
            <p className="font-semibold">{recipe.prepTime} min</p>
          </div>
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <Clock size={20} className="mx-auto mb-1 text-gray-600" />
            <p className="text-xs text-gray-600">Cook</p>
            <p className="font-semibold">{recipe.cookTime} min</p>
          </div>
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <Users size={20} className="mx-auto mb-1 text-gray-600" />
            <p className="text-xs text-gray-600">Serves</p>
            <div className="flex items-center justify-center gap-2 mt-1">
              <button
                onClick={() => setAdjustedServings(Math.max(1, adjustedServings - 1))}
                className="w-6 h-6 rounded-full bg-white border border-gray-300 flex items-center justify-center text-sm font-semibold hover:bg-gray-100"
              >
                −
              </button>
              <p className="font-semibold min-w-[2ch] text-center">{recipe.servings}</p>
              <button
                onClick={() => setAdjustedServings(adjustedServings + 1)}
                className="w-6 h-6 rounded-full bg-white border border-gray-300 flex items-center justify-center text-sm font-semibold hover:bg-gray-100"
              >
                +
              </button>
            </div>
          </div>
        </div>

        {/* Cost */}
        <div className="p-3 bg-brand-bg rounded-lg">
          <p className="text-sm text-gray-600 mb-1">Estimated cost per serving</p>
          <p className="text-2xl font-bold text-brand-teal">
            {formatCurrency(recipe.costEstimate)}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          {/* For saved recipes: Show Remix, Cook Now, Share */}
          {isRecipeSaved ? (
            <>
              {/* Cook Now - Gray out if missing ingredients */}
              <button
                onClick={handleCookNow}
                disabled={!ingredientsCheck.hasAll}
                className={`w-full flex items-center justify-center gap-2 py-3 rounded-2xl font-semibold shadow-md touch-target ${
                  ingredientsCheck.hasAll
                    ? 'bg-brand-teal text-white'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                <Share2 size={20} />
                Cook Now
              </button>

              {/* Missing ingredients warning + Add to Grocery List */}
              {!ingredientsCheck.hasAll && (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-3">
                  <div className="flex items-start gap-2">
                    <AlertCircle size={20} className="text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="font-semibold text-amber-900 text-sm">You do not have all necessary items</p>
                      <p className="text-xs text-amber-700 mt-1">
                        Missing: {ingredientsCheck.missing.map(i => i.name).join(', ')}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handleAddMissingToGrocery}
                    className="w-full flex items-center justify-center gap-2 py-2.5 bg-amber-600 text-white rounded-xl font-medium"
                  >
                    <ShoppingCart size={18} />
                    Add to Grocery List
                  </button>
                </div>
              )}

              {/* Secondary buttons */}
              <div className="flex gap-3">
                <button
                  onClick={handleRemix}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-purple-100 text-purple-700 rounded-2xl font-medium touch-target"
                >
                  <Sparkles size={18} />
                  Remix
                </button>
                <button
                  onClick={handleShare}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-blue-100 text-blue-700 rounded-2xl font-medium touch-target"
                >
                  <Share2 size={18} />
                  Share
                </button>
              </div>
            </>
          ) : (
            <>
              {/* For non-saved recipes: Original buttons */}
              <button
                onClick={handleCookNow}
                className="w-full flex items-center justify-center gap-2 py-3 bg-brand-teal text-white rounded-2xl font-semibold shadow-md touch-target"
              >
                <Share2 size={20} />
                Cook Now & Share
              </button>

              {/* Secondary: Plan Later & Add to List */}
              <div className="flex gap-3">
                <button
                  onClick={handlePlanLater}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-slate-100 text-slate-700 rounded-2xl font-medium touch-target"
                >
                  <Calendar size={18} />
                  Plan Later
                </button>
                <button
                  onClick={handleAddToList}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-slate-100 text-slate-700 rounded-2xl font-medium touch-target"
                >
                  <ShoppingCart size={18} />
                  Add to List
                </button>
              </div>

              {/* Tertiary: Re-cook, Save & Remix */}
              <div className="flex gap-3">
                <button
                  onClick={() => navigate('/post/capture', { state: { recipeId: recipe.id, recipe } })}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-slate-300 text-slate-700 rounded-2xl font-medium touch-target"
                >
                  <Repeat2 size={18} />
                  Re-cook & Post
                </button>
                <button
                  onClick={handleSaveRecipe}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 border rounded-2xl font-medium touch-target ${
                    isRecipeSaved 
                      ? 'border-brand-teal bg-brand-teal/10 text-brand-teal' 
                      : 'border-slate-300 text-slate-700'
                  }`}
                >
                  <Bookmark size={18} className={isRecipeSaved ? 'fill-current' : ''} />
                  {isRecipeSaved ? 'Saved' : 'Save'}
                </button>
                <button
                  onClick={handleRemix}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-slate-300 text-slate-700 rounded-2xl font-medium touch-target"
                >
                  <Sparkles size={18} />
                  Remix
                </button>
              </div>
            </>
          )}
        </div>

        {/* AI Prompt Modal - Show when can't cook due to missing ingredients */}
        {showAIPrompt && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-6 max-w-sm w-full space-y-4">
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Sparkles size={32} className="text-purple-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Can't make this?</h3>
                <p className="text-gray-600 text-sm">
                  Hey, you can't make this recipe right now, but use our AI to create a cool recipe with what you have!
                </p>
              </div>
              <div className="space-y-2">
                <button
                  onClick={() => {
                    setShowAIPrompt(false);
                    navigate('/chef', { state: { openAI: true } });
                  }}
                  className="w-full py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-semibold"
                >
                  Use AI Assistant
                </button>
                <button
                  onClick={() => {
                    setShowAIPrompt(false);
                    setShowMissingModal(true);
                  }}
                  className="w-full py-3 bg-gray-100 text-gray-700 rounded-xl font-medium"
                >
                  Add Missing Items to Grocery List
                </button>
                <button
                  onClick={() => setShowAIPrompt(false)}
                  className="w-full py-2 text-gray-500 text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Missing Ingredients Modal */}
        {showMissingModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-6 max-w-sm w-full space-y-4">
              <h3 className="text-lg font-bold">Missing Ingredients</h3>
              <div className="space-y-2">
                {ingredientsCheck.missing.map((ing, idx) => (
                  <div key={idx} className="flex justify-between text-sm p-2 bg-gray-50 rounded-lg">
                    <span className="font-medium">{ing.name}</span>
                    <span className="text-gray-600">{ing.amount} {ing.unit}</span>
                  </div>
                ))}
              </div>
              <p className="text-sm text-gray-600">
                Do you want to add these to your grocery list?
              </p>
              <div className="flex gap-2">
                <button
                  onClick={handleAddMissingToGrocery}
                  className="flex-1 py-2.5 bg-brand-teal text-white rounded-xl font-medium"
                >
                  Add to List
                </button>
                <button
                  onClick={() => setShowMissingModal(false)}
                  className="flex-1 py-2.5 bg-gray-100 text-gray-700 rounded-xl font-medium"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Ingredients */}
        <div>
          <h2 className="text-lg font-bold mb-3">Ingredients</h2>
          <ul className="space-y-2">
            {recipe.ingredients.map((ing) => (
              <li key={ing.id} className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
                <div className="w-5 h-5 rounded-full border-2 border-brand-teal flex items-center justify-center flex-shrink-0">
                  <div className="w-2 h-2 rounded-full bg-brand-teal"></div>
                </div>
                <span className="text-sm">
                  <span className="font-semibold">{ing.amount} {ing.unit}</span> {ing.name}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Steps */}
        <div>
          <h2 className="text-lg font-bold mb-3">Instructions</h2>
          <ol className="space-y-4">
            {recipe.steps.map((step, index) => (
              <li key={index} className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-brand-teal text-white flex items-center justify-center font-bold text-sm">
                  {index + 1}
                </div>
                <p className="flex-1 text-gray-700 leading-relaxed pt-1">{step}</p>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </Screen>
  );
}

