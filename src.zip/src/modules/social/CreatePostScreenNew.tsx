import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Star, Camera, ChefHat, Sparkles } from 'lucide-react';
import { useAuth } from '../../providers/AuthProvider';
import { useAppStore } from '../../store/appStore';
import { useToast } from '../../components/ui/ToastContext';
import type { Post, Recipe } from '../../types';
import { Button } from '../../components/ui/Button';

export function CreatePostScreenNew() {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { user } = useAuth();
  const addPost = useAppStore((state) => state.addPost);
  const recipes = useAppStore((state) => state.recipes);
  const savedRecipes = useAppStore((state) => state.savedRecipes);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [image, setImage] = useState<string>('');
  const [description, setDescription] = useState('');
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [ingredients, setIngredients] = useState('');
  const [recipeSteps, setRecipeSteps] = useState('');
  const [showRecipeImport, setShowRecipeImport] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [privacy, setPrivacy] = useState<'private' | 'friends' | 'global'>('global');
  const [servings, setServings] = useState(2);

  // Get saved AI recipes
  const savedAIRecipes = recipes.filter(r => savedRecipes.includes(r.id));

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Convert to base64 for localStorage persistence
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRecipeImport = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setDescription(recipe.description);
    setIngredients(recipe.ingredients.map(i => `${i.amount} ${i.unit} ${i.name}`).join('\n'));
    setRecipeSteps(recipe.steps.join('\n'));
    if (recipe.image) {
      setImage(recipe.image);
    }
    setShowRecipeImport(false);
    showToast('Recipe imported successfully!', 'success');
  };

  const handlePost = async () => {
    if (!user) {
      showToast('You must be logged in to post', 'error');
      return;
    }

    // Image is optional only for private posts
    if (!image && privacy !== 'private') {
      showToast('Please add an image to your post', 'error');
      return;
    }

    if (!description.trim()) {
      showToast('Please add a description', 'error');
      return;
    }

    setIsSubmitting(true);

    try {
      const postUser = {
        id: user.id,
        username: user.username,
        displayName: user.displayName || user.username,
        avatar: user.avatar || undefined,
        bio: user.bio,
        followers: 0,
        following: 0,
        mealsShared: 0,
        wasteReduced: 0,
        avgCostPerServing: 0,
        badges: user.badges || [],
      };

      const ingredientsList = ingredients.trim() 
        ? ingredients.split('\n').map(i => i.trim()).filter(i => i.length > 0)
        : undefined;

      const stepsList = recipeSteps.trim()
        ? recipeSteps.split('\n').map(s => s.trim()).filter(s => s.length > 0)
        : undefined;

      // Calculate cost based on ingredients (simple AI estimation)
      const calculateCost = (ingredientList?: string[]): number => {
        if (!ingredientList || ingredientList.length === 0) {
          return 3.50; // Default
        }
        
        // Simple cost estimation based on ingredient count and common prices
        const basePrice = 1.50; // Base price per serving
        const ingredientCount = ingredientList.length;
        
        // Check for expensive ingredients
        const expensiveKeywords = ['beef', 'steak', 'salmon', 'shrimp', 'seafood', 'cheese', 'parmesan'];
        const cheapKeywords = ['rice', 'pasta', 'beans', 'lentils', 'potato', 'egg'];
        
        let costMultiplier = 1.0;
        
        ingredientList.forEach(ingredient => {
          const lower = ingredient.toLowerCase();
          if (expensiveKeywords.some(kw => lower.includes(kw))) {
            costMultiplier += 0.5;
          }
          if (cheapKeywords.some(kw => lower.includes(kw))) {
            costMultiplier -= 0.2;
          }
        });
        
        // Calculate final cost: base + (ingredient count * 0.3) * multiplier
        const estimatedCost = (basePrice + (ingredientCount * 0.3)) * Math.max(0.5, costMultiplier);
        return Math.round(estimatedCost * 100) / 100; // Round to 2 decimals
      };

      const estimatedCost = calculateCost(ingredientsList);

      // Create recipe object if ingredients/steps provided
      let recipeForPost = selectedRecipe;
      if (!selectedRecipe && (ingredientsList || stepsList)) {
        recipeForPost = {
          id: `recipe-${crypto.randomUUID()}`,
          userId: user.id,
          title: description.split('\n')[0].slice(0, 50) || 'My Recipe',
          description: description,
          ingredients: (ingredientsList || []).map((ing, idx) => ({
            id: `ing-${idx}`,
            name: ing,
            amount: 1,
            unit: 'unit',
          })),
          steps: stepsList || [],
          servings: servings,
          prepTime: 0,
          cookTime: 0,
          costEstimate: estimatedCost,
          tags: [],
          reCookCount: 0,
          createdAt: new Date(),
        };
      }

      const newPost: Post = {
        id: crypto.randomUUID(),
        userId: user.id,
        user: postUser,
        type: 'meal',
        privacy: privacy,
        media: image ? [image] : [],
        caption: description,
        recipeId: recipeForPost?.id,
        recipe: recipeForPost || undefined,
        stats: {
          costPerServing: estimatedCost,
          wasteSaved: 0,
          expiringItemsUsed: 0,
        },
        badges: selectedRecipe ? ['AI-RECIPE'] : [],
        likes: 0,
        comments: 0,
        reCooks: 0,
        createdAt: new Date(),
        rating: rating > 0 ? rating : undefined,
        reactions: { youCooked: 0, youreCooked: 0 },
        userReaction: null,
        ingredients: ingredientsList,
        recipeSteps: stepsList,
        isAIGenerated: !!selectedRecipe,
      };

      addPost(newPost);

      // Deduct ingredients from inventory if recipe has ingredients
      if (recipeForPost?.ingredients && recipeForPost.ingredients.length > 0) {
        const ingredientsToDeduct = recipeForPost.ingredients.map(ing => ({
          name: ing.name,
          amount: ing.amount,
          unit: ing.unit,
        }));
        useAppStore.getState().deductIngredientsFromInventory(ingredientsToDeduct);
        showToast('Post created & ingredients deducted from pantry! 🎉', 'success');
      } else {
        showToast('Post created successfully! 🎉', 'success');
      }

      navigate('/home');
    } catch (error) {
      console.error('Error creating post:', error);
      showToast('Failed to create post', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white">
        <p className="text-gray-500">You must be logged in to create a post.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-white">
      {/* Header - Fixed */}
      <div className="flex-shrink-0 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between z-10">
        <button
          onClick={() => navigate(-1)}
          className="p-2 -ml-2 touch-target"
          aria-label="Cancel"
        >
          <X size={24} className="text-slate-900" />
        </button>
        <h1 className="text-lg font-semibold text-slate-900">Create Post</h1>
        <Button
          onClick={handlePost}
          disabled={!image || !description.trim() || isSubmitting}
          size="sm"
          variant="primary"
        >
          {isSubmitting ? 'Posting...' : 'Post'}
        </Button>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="px-4 py-6 space-y-6">
          {/* Image Upload - Compact at top */}
          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">
              Photo <span className="text-red-500">*</span>
            </label>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />
            {image ? (
              <div className="relative">
                <img
                  src={image}
                  alt="Preview"
                  className="w-full h-48 object-cover rounded-2xl"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute top-3 right-3 p-2 bg-black/50 rounded-full text-white touch-target"
                >
                  <Camera size={20} />
                </button>
              </div>
            ) : (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-32 border-2 border-dashed border-slate-300 rounded-2xl flex flex-col items-center justify-center gap-2 hover:border-brand-teal transition-colors touch-target"
              >
                <Camera size={32} className="text-slate-400" />
                <p className="text-sm text-slate-600">Tap to add a photo</p>
              </button>
            )}
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">
              Description <span className="text-red-500">*</span>
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Share your cooking experience, tips, or thoughts about this dish..."
              className="w-full min-h-[120px] p-3 border border-slate-200 rounded-2xl resize-none focus:outline-none focus:ring-2 focus:ring-brand-teal focus:border-transparent"
            />
          </div>

          {/* Privacy Selector */}
          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">
              Who can see this?
            </label>
            <div className="flex gap-2">
              <button
                onClick={() => setPrivacy('private')}
                className={`flex-1 py-2 px-3 rounded-xl text-sm font-medium transition-all ${
                  privacy === 'private'
                    ? 'bg-brand-teal text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Private
              </button>
              <button
                onClick={() => setPrivacy('friends')}
                className={`flex-1 py-2 px-3 rounded-xl text-sm font-medium transition-all ${
                  privacy === 'friends'
                    ? 'bg-brand-teal text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Friends
              </button>
              <button
                onClick={() => setPrivacy('global')}
                className={`flex-1 py-2 px-3 rounded-xl text-sm font-medium transition-all ${
                  privacy === 'global'
                    ? 'bg-brand-teal text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Global
              </button>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {privacy === 'private' && 'Only you can see this post'}
              {privacy === 'friends' && 'Only your friends can see this'}
              {privacy === 'global' && 'Everyone can see this on Discover'}
            </p>
          </div>

          {/* Servings Input */}
          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">
              Number of servings
            </label>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setServings(Math.max(1, servings - 1))}
                className="w-10 h-10 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-xl font-semibold text-slate-700 touch-target"
              >
                −
              </button>
              <input
                type="number"
                min="1"
                max="20"
                value={servings}
                onChange={(e) => setServings(Math.max(1, Math.min(20, parseInt(e.target.value) || 1)))}
                className="w-20 text-center text-lg font-semibold border border-slate-200 rounded-xl py-2"
              />
              <button
                onClick={() => setServings(Math.min(20, servings + 1))}
                className="w-10 h-10 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-xl font-semibold text-slate-700 touch-target"
              >
                +
              </button>
              <span className="text-sm text-slate-600">servings</span>
            </div>
          </div>

          {/* Star Rating - GREEN STARS */}
          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">
              Rate your dish
            </label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="touch-target"
                >
                  <Star
                    size={32}
                    className={`${
                      star <= (hoveredRating || rating)
                        ? 'fill-brand-teal text-brand-teal'
                        : 'text-slate-300'
                    } transition-colors`}
                  />
                </button>
              ))}
            </div>
            {rating > 0 && (
              <p className="text-sm text-slate-600 mt-2">
                {rating === 1 && "Needs improvement"}
                {rating === 2 && "It was okay"}
                {rating === 3 && "Pretty good!"}
                {rating === 4 && "Delicious!"}
                {rating === 5 && "Absolutely amazing!"}
              </p>
            )}
          </div>

          {/* Import AI Recipe Button */}
          {savedAIRecipes.length > 0 && (
            <div>
              <Button
                onClick={() => setShowRecipeImport(true)}
                variant="ghost"
                className="w-full border border-brand-teal text-brand-teal flex items-center justify-center gap-2"
              >
                <Sparkles size={18} />
                Import AI Recipe
              </Button>
              {selectedRecipe && (
                <div className="mt-2 p-3 bg-brand-teal/10 border border-brand-teal/20 rounded-xl">
                  <div className="flex items-center gap-2 text-sm text-brand-teal">
                    <ChefHat size={16} />
                    <span className="font-medium">Using: {selectedRecipe.title}</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Ingredients - Optional */}
          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">
              Ingredients (Optional)
            </label>
            <textarea
              value={ingredients}
              onChange={(e) => setIngredients(e.target.value)}
              placeholder="2 cups flour&#10;1 tsp salt&#10;3 eggs&#10;..."
              className="w-full min-h-[100px] p-3 border border-slate-200 rounded-2xl resize-none focus:outline-none focus:ring-2 focus:ring-brand-teal focus:border-transparent font-mono text-sm"
            />
            <p className="text-xs text-slate-500 mt-1">One ingredient per line</p>
          </div>

          {/* Recipe Steps - Optional */}
          <div>
            <label className="block text-sm font-semibold text-slate-900 mb-2">
              Recipe Steps (Optional)
            </label>
            <textarea
              value={recipeSteps}
              onChange={(e) => setRecipeSteps(e.target.value)}
              placeholder="Mix dry ingredients&#10;Add wet ingredients&#10;Bake for 30 minutes&#10;..."
              className="w-full min-h-[100px] p-3 border border-slate-200 rounded-2xl resize-none focus:outline-none focus:ring-2 focus:ring-brand-teal focus:border-transparent font-mono text-sm"
            />
            <p className="text-xs text-slate-500 mt-1">One step per line</p>
          </div>

          {/* Bottom padding to ensure scrollability */}
          <div className="h-20" />
        </div>
      </div>

      {/* Recipe Import Modal */}
      {showRecipeImport && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl w-full sm:max-w-md max-h-[80vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
              <h2 className="text-lg font-semibold">Import Recipe</h2>
              <button
                onClick={() => setShowRecipeImport(false)}
                className="p-2 -mr-2 touch-target"
              >
                <X size={24} />
              </button>
            </div>
            <div className="p-4 space-y-3">
              {savedAIRecipes.length === 0 ? (
                <p className="text-sm text-slate-600 text-center py-8">
                  No saved AI recipes yet. Generate some recipes in the Chef tab!
                </p>
              ) : (
                savedAIRecipes.map((recipe) => (
                  <button
                    key={recipe.id}
                    onClick={() => handleRecipeImport(recipe)}
                    className="w-full p-4 border border-slate-200 rounded-xl hover:border-brand-teal hover:bg-brand-teal/5 transition-colors text-left touch-target"
                  >
                    <div className="flex gap-3">
                      {recipe.image && (
                        <img
                          src={recipe.image}
                          alt={recipe.title}
                          className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                        />
                      )}
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-slate-900 truncate">
                          {recipe.title}
                        </h3>
                        <p className="text-sm text-slate-600 line-clamp-2 mt-1">
                          {recipe.description}
                        </p>
                        <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
                          <span>{recipe.ingredients.length} ingredients</span>
                          <span>•</span>
                          <span>{recipe.prepTime + recipe.cookTime} min</span>
                        </div>
                      </div>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
