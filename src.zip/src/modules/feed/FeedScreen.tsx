import { PostList } from '../../components/social/PostList';
import { useFeedQuery } from '../../hooks/useFeed';
import { Screen } from '../../components/layout/Screen';
import { useAppStore } from '../../store/appStore';
import { PullToRefresh } from '../../components/ui/PullToRefresh';
import { MessageCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../providers/AuthProvider';

export function FeedScreen() {
  const navigate = useNavigate();
  const { data: apiPosts, isLoading, isError, refetch } = useFeedQuery();
  const { user } = useAuth();
  // Always use Zustand store posts as source of truth (includes localStorage)
  const storePosts = useAppStore((state) => state.posts);
  const conversations = useAppStore((state) => state.conversations);
  
  // Count unread messages
  const unreadCount = conversations.filter(
    conv => conv.lastMessage && !conv.lastMessage.isRead
  ).length;
  
  // Use store posts as primary source (they include localStorage posts)
  // Store posts are reactive - when a new post is added, this component will re-render
  // If API has additional posts, merge them (avoiding duplicates)
  const allPostIds = new Set(storePosts.map(p => p.id));
  const additionalApiPosts = apiPosts?.filter(p => !allPostIds.has(p.id)) || [];
  
  // Combine and sort by date (newest first)
  const allPosts = [...storePosts, ...additionalApiPosts].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  // Filter out user's own posts, except the most recent one (if posted in last 5 minutes)
  const displayPosts = allPosts.filter((post) => {
    if (!user) return true;
    
    const isOwnPost = post.userId === user.id || post.user.username === user.username;
    if (!isOwnPost) return true;
    
    // Show only the most recent own post, and only if it's less than 5 minutes old
    const userPosts = allPosts.filter(p => p.userId === user.id || p.user.username === user.username);
    const isNewest = userPosts[0]?.id === post.id;
    const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
    const isRecent = new Date(post.createdAt).getTime() > fiveMinutesAgo;
    
    return isNewest && isRecent;
  });

  const handleRefresh = async () => {
    await refetch();
  };

  return (
    <Screen>
      {/* Header with Cookd Logo and Messages Button */}
      <div className="sticky top-0 z-40 bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
        <h1 className="text-xl font-bold text-brand-teal">Cookd</h1>
        <button
          onClick={() => navigate('/messages')}
          className="relative p-2 touch-target"
          aria-label="Messages"
        >
          <MessageCircle size={24} className="text-slate-900" />
          {unreadCount > 0 && (
            <div className="absolute top-1 right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
              <span className="text-xs text-white font-semibold">{unreadCount}</span>
            </div>
          )}
        </button>
      </div>

      <PullToRefresh onRefresh={handleRefresh}>
        <PostList
          posts={displayPosts}
          isLoading={isLoading && storePosts.length === 0}
          isError={isError && storePosts.length === 0}
          onRetry={() => refetch()}
        />
      </PullToRefresh>
    </Screen>
  );
}

